package com.example.servicetest;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.dto.InsuredDto;
import com.example.entities.Broker;
import com.example.entities.Insured;
import com.example.repository.BrokerRepo;
import com.example.repository.InsuredRepo;
import com.example.service.InsuredService;

@SpringBootTest
public class InsuredServiceTest {

    @Autowired
    private InsuredService insuredService;

    @Autowired
    private BrokerRepo brokerRepo;

    @Autowired
    private InsuredRepo insuredRepo;

    @Test
    void testSaveInsuredWithQuote() {
        // Arrange: Create and save a broker in the database for association.
        Broker broker = new Broker();
        broker.setName("Test Broker");
        broker.setEmail("broker@example.com");
        broker.setPassword("password");
        broker = brokerRepo.save(broker); // Persist the broker into the database.

        // Prepare the InsuredDto object.
        InsuredDto insuredDto = new InsuredDto();
        insuredDto.setBrokerid(broker.getId());
        insuredDto.setName("John Doe");
        insuredDto.setOccupation("Software Engineer");
       
        // Act: Call the method to save the insured with the quote.
        long insuredId = insuredService.saveinsuredWithQuote(insuredDto);

        // Assert: Verify the insured is saved correctly.
        Insured insured = insuredRepo.findById(insuredId).orElse(null); // Fetch the saved insured.

        assertNotNull(insured);
        assertEquals("John Doe", insured.getName());
        assertEquals("Software Engineer", insured.getOccupation());
       
        assertEquals(broker.getId(), insured.getBroker().getId()); // Verify broker association.
    }
    
    
}
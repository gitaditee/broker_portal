package com.example.servicetest;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import org.junit.jupiter.api.Test;
import com.example.dto.brokerRegisterdto;
import com.example.entities.Broker;
import com.example.repository.BrokerRepo;
import com.example.service.BrokerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class BrokerServiceTest {

    @Autowired
    private BrokerService brokerser;
    private BrokerRepo brepo; 
    @Test
    void brokershouldregister() {
        // Create a test DTO
        brokerRegisterdto bdto = new brokerRegisterdto();
        bdto.setEmail("test@example.com");
        bdto.setPassword("password");
        bdto.setName("Test Name");

        // Call the method
        brokerser.registerUser(bdto);

        // Assertions or validations can follow
        System.out.print(false);
    }
    
}



  
    


package com.example.servicetest;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.example.dto.RiskFactordto;
import com.example.entities.Quote;
import com.example.entities.RiskFactor;
import com.example.repository.QuoteRepo;
import com.example.repository.RiskFactorRepo;
import static org.junit.jupiter.api.Assertions.*;
import com.example.dto.RiskFactordto;
import com.example.repository.QuoteRepo;
import com.example.repository.RiskFactorRepo;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class RiskFactorService {

    @Autowired
    private RiskFactorService riskFactorService;

    @Autowired
    private QuoteRepo quoteRepo;

    @Autowired
    private RiskFactorRepo riskFactorRepo;

    @Test
    void testSaveRiskFactor() {
    }
}


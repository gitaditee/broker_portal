package com.example.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.dto.InsuredDto;
import com.example.entities.Quote;
import com.example.security.JwtUtil;
import com.example.service.InsuredServiceImpl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/add_client")
@CrossOrigin(origins = "*")
public class InsuredController {

    @Autowired
    private InsuredServiceImpl inser; 
    @Autowired
    private JwtUtil jwtUtil;
        @PostMapping("/createWithQuote")
        public ResponseEntity<Map<String, String>> addClientWithQuote(@RequestBody InsuredDto insuredata,
        		@RequestHeader("Authorization") String token) {
            Map<String, String> response = new HashMap<>();
            String role = jwtUtil.extractRole(token.replace("Bearer ", ""));
            if (!"BROKER".equals(role)) {
              
                response.put("error", "Unauthorized role");
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(response);
            }

            Long brokerId = jwtUtil.extractEntityId(token.replace("Bearer ", ""));
            
            insuredata.setBrokerid(brokerId);

            long insuredid=inser.saveinsuredWithQuote(insuredata);

            response.put("message", "Insured with quotes saved successfully!");
            response.put("insured id" ,String.valueOf(insuredid));
            return ResponseEntity.ok().contentType(MediaType.APPLICATION_JSON).body(response);
        }
    
    @GetMapping("/{insuredId}/quotes")
    public ResponseEntity<List<Quote>> getQuotesByInsuredId(@PathVariable long insuredId) {
        List<Quote> quotes = inser.getQuotesByInsuredId(insuredId);
        return ResponseEntity.ok(quotes);
    }
    
   

        @DeleteMapping("/deletecustomer/{insuredId}")
        public void deleteCustomer(@PathVariable("insuredId") long insuredId) {
            
                inser.deleteCustomer(insuredId);
            
    }

}
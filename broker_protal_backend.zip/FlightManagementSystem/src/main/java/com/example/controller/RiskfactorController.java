package com.example.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.dto.RiskFactordto;
import com.example.entities.RiskFactor;
import com.example.repository.RiskFactorRepo;
import com.example.service.RiskFactorServiceImpl;
import com.example.values.RiskFactors;

@RestController
@RequestMapping("/factors")
@CrossOrigin(origins = "*")
public class RiskfactorController {

    @Autowired
    private RiskFactorServiceImpl rfservice;

    @Autowired
    private RiskFactorRepo rfrepo;
    @PostMapping("/riskfactors")
    public ResponseEntity<RiskFactordto> getRiskFactor(@RequestParam Long quoteid, @RequestBody RiskFactors rfs) {
        RiskFactordto rfdto = new RiskFactordto();
        rfdto.setQuoteid(quoteid);
        if (rfs.isForbusiness()) {
            rfdto.setForbusiness(1.0);
        } else {
            rfdto.setForbusiness(0.85);
        }
        if (rfs.isInconstrn()) {
            rfdto.setInconstrn(1.1);
        } else {
            rfdto.setInconstrn(0.89);
        }
        if (rfs.isPoorcodn()) {
            rfdto.setPoorcodn(1.2);
        } else {
            rfdto.setPoorcodn(0.92);
        }
        if (rfs.isUnoccupied()) {
            rfdto.setUnoccupied(1.25);
        } else {
            rfdto.setUnoccupied(0.90);
        }
        if (rfs.isHostels()) {
            rfdto.setHostels(1.1);
        } else {
            rfdto.setHostels(0.82);
        }

        rfservice.saveRiskFactor(rfdto);
        return ResponseEntity.ok(rfdto);
    }

    @PostMapping("/multipler")
    @CrossOrigin(origins = "http://localhost:4200")  // Allow frontend calls
    public ResponseEntity<Map<String, Object>> calculateMultiplier(@RequestParam Long quoteid) {
        try {
            // Retrieve the correct RiskFactor from the database
            RiskFactor rfcal = rfrepo.findByQuoteId(quoteid)
                    .orElseThrow(() -> new RuntimeException("RiskFactor not found for quote ID: " + quoteid));

            double multiplier = rfservice.calmultiplier(quoteid);

            // Prepare a map with both values
            Map<String, Object> response = new HashMap<>();
            response.put("riskFactorId", rfcal.getId());
            response.put("multiplier", multiplier);

            return ResponseEntity.ok(response);
        } catch (Exception e) {
            return ResponseEntity.status(500).body(null);
        }
    }
}
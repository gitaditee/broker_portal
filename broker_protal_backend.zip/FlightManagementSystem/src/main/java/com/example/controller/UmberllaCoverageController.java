
package com.example.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.dto.UmberllaCoveragedto;
import com.example.entities.RiskFactor;
import com.example.entities.UmberllaCoverage;
import com.example.repository.UmberllaCoverageRepo;
import com.example.service.UmberllaCoverageImpl;
import com.example.values.UmberllaCoverages;

@RestController
@RequestMapping("/umbrella-coverages")
@CrossOrigin(origins = "*")
public class UmberllaCoverageController {

    @Autowired
    private UmberllaCoverageImpl umbrellaCoverageService;
    @Autowired
    private UmberllaCoverageRepo umcvrepo;
    @PostMapping("/set-coverages")
    public ResponseEntity<?> setUmbrellaCoverages(
            @RequestParam long quoteid,
            @RequestBody UmberllaCoverages coverageValues) {
        try {
            
            UmberllaCoveragedto dto = new UmberllaCoveragedto();
            dto.setQuoteid(quoteid);

            // Set coverage factors based on input
            dto.setBodily_injured(coverageValues.isBodily_injured() ? 20000 : 0);
            dto.setDog_bite(coverageValues.isDog_bite() ? 10000 : 0);
            dto.setLandlord_liablity(coverageValues.isLandlord_liablity() ? 15000 : 0);
            dto.setProperty_damage(coverageValues.isProperty_damage() ? 25000 : 0);


            umbrellaCoverageService.saveriskfactors(dto);

            return ResponseEntity.ok(dto);
        } catch (RuntimeException ex) {
           
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(ex.getMessage());
        }
    }

    @PostMapping("/calculate-multiplier")
    public ResponseEntity<Map<String, Object>> calculateMultiplier(@RequestParam Long quoteid) {
        try {
        	 UmberllaCoverage umcv =umcvrepo.findByQuoteId(quoteid)
                     .orElseThrow(() -> new RuntimeException("RiskFactor not found for quote ID: " + quoteid));
            double multiplier = umbrellaCoverageService.calmultiplier(quoteid);
            Map<String, Object> response = new HashMap<>();
            
            response.put("umcvId",umcv.getId());
            response.put("multiplier", multiplier);
            return ResponseEntity.ok(response);
        } catch (RuntimeException ex) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(null);
        }
    }
}
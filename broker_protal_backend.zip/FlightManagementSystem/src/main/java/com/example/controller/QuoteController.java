package com.example.controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.example.dto.HomePermiumCaldto;
import com.example.dto.QuoteDto;
import com.example.dto.RiskFactordto;
import com.example.entities.Quote;
import com.example.service.QuoteService;
import com.example.service.QuoteServiceImpl;

@RestController
@RequestMapping("/quote")
@CrossOrigin(origins = "*")
public class QuoteController {
	@Autowired
	QuoteServiceImpl qserimpl=new QuoteServiceImpl();
	    @PostMapping("/createQuote")
	    public Quote createQuote(@RequestParam Long insuredId) {
	        
	        Quote quote = qserimpl.createQuote( insuredId);
	       
	        System.out.println("Quote created for Insured ID: " + insuredId);
	        return quote;
	    }
	    
	   @GetMapping("/getDeatils/{quoteId}")
	   public QuoteDto getQuotedetails(@PathVariable long quoteId) {
		   return qserimpl.getQuoteDetails(quoteId);
	   }
	   
	   @PostMapping("/setStatus")
	   public QuoteDto setStatus(@RequestParam long quoteid,double st) {
		   
		   return qserimpl.setStatusquote(quoteid,st);
	   }
	   
	}
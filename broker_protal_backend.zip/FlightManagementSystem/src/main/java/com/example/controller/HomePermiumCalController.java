package com.example.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.entities.HomePermiumCal;
import com.example.service.HomePermiumCalImpl;

@RestController
@RequestMapping("/homepremium")
@CrossOrigin(origins = "*")
public class HomePermiumCalController {

    @Autowired
    private HomePermiumCalImpl homePremiumService;

    @PostMapping("/base_per")
    public ResponseEntity<Map<String, Object>> calculateHomePremium(
            @RequestParam double coverage,
            @RequestParam long quoteid,
            @RequestParam long multiplierId) {
        try {
            // Save coverage information
            homePremiumService.saveCoverage(coverage, quoteid);

            // Calculate base premium
            double basePremium = homePremiumService.calbaseper(quoteid, multiplierId);

            // Prepare response map
            Map<String, Object> response = new HashMap<>();
            response.put("coverage", coverage);
            response.put("quoteId", quoteid);
            response.put("multiplierId", multiplierId);
            response.put("basePremium", basePremium);

            return ResponseEntity.ok(response);
        } catch (RuntimeException ex) {
            Map<String, Object> errorResponse = new HashMap<>();
            errorResponse.put("error", ex.getMessage());
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(errorResponse);
        }
    }
    @PostMapping("/user-coverage")
    public ResponseEntity<HomePermiumCal> calculateHomePremium(
            @RequestParam double coverage, @RequestParam long quoteid) {
        HomePermiumCal savedPremium = homePremiumService.saveHomeCoverage(coverage, quoteid);
        return ResponseEntity.ok(savedPremium);
    }
    

}
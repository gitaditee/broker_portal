package com.example.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.dto.UmberllaRiskFactorDto;
import com.example.entities.UmberllaCoverage;
import com.example.entities.UmberllaRiskFactor;
import com.example.repository.UmberllaRiskFactorRepo;
import com.example.service.UmberllaRiskFactorService;
import com.example.values.UmberllaRiskFactors;

@RestController
@RequestMapping("/umbrella-risk-factors")
@CrossOrigin(origins = "*")
public class UmberllaRiskFactorController {

    @Autowired
    private UmberllaRiskFactorService riskFactorService;
    @Autowired
    private UmberllaRiskFactorRepo umrfrepo;
    @PostMapping("/set-risk-factor")
    public void setUmbrellaRiskFactors(
            @RequestParam long quoteid,
            @RequestBody UmberllaRiskFactors riskFactors 
    ) {
        
        UmberllaRiskFactorDto riskFactorDto = new UmberllaRiskFactorDto();
        riskFactorDto.setAgeof_home(quoteid);

        riskFactorDto.setQuoteid(quoteid);
        riskFactorDto.setHasswimmingpool(riskFactors.isHasswimmingpool() ? 1.1 :0.85);
        riskFactorDto.setHaskids(riskFactors.isHaskids() ? 1.2 : 0.95);
        riskFactorDto.setHaspets(riskFactors.isHaspets() ?  1.1 :0.95);
        riskFactorDto.setIsfrequent_guest(riskFactors.isIsfrequent_guest() ? 1.12 : 0.85);
        riskFactorDto.setOnrent(riskFactors.isOnrent() ?1.0 : 8.6);

        
         riskFactorService.saveRiskFactors(riskFactorDto);
    }


    @PostMapping("/calculate-multiplier")
    public ResponseEntity<Map<String, Object>> calculateMultiplier(@RequestParam Long quoteid) {
        try {
        	 UmberllaRiskFactor umrf =umrfrepo.findByQuoteId(quoteid)
                     .orElseThrow(() -> new RuntimeException("RiskFactor not found for quote ID: " + quoteid));
            double multiplier = riskFactorService.calculateRiskMultiplier(quoteid);
            Map<String, Object> response = new HashMap<>();
            
            response.put("umrfId",umrf.getId());
            response.put("multiplier", multiplier);
            return ResponseEntity.ok(response);
        } catch (RuntimeException ex) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(null);
        }
    }
   
}
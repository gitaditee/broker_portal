

package com.example.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.dto.UmberllaPreniumCaldto;
import com.example.service.UmberllaPreImpl;
import com.example.values.UmberllaPerCalValues;

@RestController
@RequestMapping("/umbrella-premium-calculator")
@CrossOrigin(origins = "*")
public class UmberllaPreniumCalController {

    @Autowired
    private UmberllaPreImpl umservice;

    
    @PostMapping("/calculate-premium")
    public ResponseEntity<Double> calculatePremium(
            @RequestParam Long quoteid, 
            @RequestParam Long riskid,
            @RequestParam Long cvid, 
            @RequestBody UmberllaPerCalValues umval 
    ) {
        
        UmberllaPreniumCaldto umdto = new UmberllaPreniumCaldto();
        umdto.setQuoteid(quoteid); 
        umdto.setCoverage(umval.getCoverage());
        umdto.setPercent(umval.getPercent());

      
        double calculatedPremium = umservice.calculatePremium(quoteid, riskid, cvid, umdto);

        return ResponseEntity.ok(calculatedPremium);
    }
    
    @PostMapping("/calculate-um-premium")
    public ResponseEntity<Double> calculateOnlyPremium(
            @RequestParam Long quoteid, 
            @RequestParam Long riskid,
            @RequestParam Long cvid, 
            @RequestBody UmberllaPerCalValues umval 
    ){
    	 UmberllaPreniumCaldto umdto = new UmberllaPreniumCaldto();
         umdto.setQuoteid(quoteid); 
         umdto.setCoverage(umval.getCoverage());
         umdto.setPercent(umval.getPercent());

       
         double calculatedPremium = umservice.calculateonlyUmPremium(quoteid, riskid, cvid, umdto);

         return ResponseEntity.ok(calculatedPremium);
    }
}
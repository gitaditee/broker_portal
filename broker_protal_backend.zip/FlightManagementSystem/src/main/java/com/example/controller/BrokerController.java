package com.example.controller;

import java.util.Collection;
import java.util.List;
import java.util.Map;

import org.hibernate.engine.internal.Collections;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.service.*;
import com.fasterxml.jackson.annotation.JsonBackReference;
import com.example.entities.*;
import com.example.security.JwtUtil;
import com.example.dto.*;
@RestController
@RequestMapping("/broker")
@CrossOrigin(origins = "*")
public class BrokerController {
	@Autowired
	BrokerService brokerservice;		
	@Autowired
	private JwtUtil jwtUtil;	
	@PostMapping(value="/register")
	public ResponseEntity<String> registerBroker(@RequestBody brokerRegisterdto bdto) {
		try {
			brokerservice.registerUser(bdto);
			return ResponseEntity.ok("broker registered successfully!");
		}
		catch(Exception e) {
			return ResponseEntity.ok("broker registered unsccessfully!");
		}		
	}
	
	
	@PostMapping("/login")
	public ResponseEntity<?> login(@RequestBody brokerRegisterdto bdto) {
 
	    Broker broker =  brokerservice.loginUser(bdto);
	    if (broker != null) {
	        String token = jwtUtil.generateToken("BROKER", broker.getId());
	        return ResponseEntity.ok(Map.of(
	        		"token", token,
	        		"role", "BROKER",
	        		"broker", broker
	        ));
	    } else {
	        return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid credentials");
	    }
	}
	
	@GetMapping("/{id}/insured")	
	public List<Insured> getAllInsured(@PathVariable long id) {
	    if (id <= 0) {
	        throw new IllegalArgumentException("Invalid broker ID");
	    }
	    try {
	        return brokerservice.getInsuredByBrokerId(id);
	    } catch (Exception e) {
	        e.printStackTrace();
	        throw new RuntimeException("Error fetching insured list: " + e.getMessage());
	    }
	}
	}
	    


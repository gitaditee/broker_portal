package com.example.entities;
import java.util.Date;

import com.example.dto.HomePermiumCaldto;
import com.example.dto.RiskFactordto;
import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonManagedReference;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToOne;
import lombok.Data;
@Entity
@Data
public class Quote {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    @OneToOne(mappedBy="quote" ,cascade = CascadeType.ALL)
    @JsonManagedReference
    private RiskFactor riskFactors;
    @OneToOne(mappedBy="quote",cascade = CascadeType.ALL)
    @JsonManagedReference
    private HomePermiumCal homePremiumDetails;
    @OneToOne(mappedBy="quote",cascade = CascadeType.ALL)
    @JsonManagedReference
    private UmberllaCoverage umcv;
    @OneToOne(mappedBy="quote",cascade = CascadeType.ALL)
    @JsonManagedReference
    private UmberllaRiskFactor umrf;
    @OneToOne(mappedBy="quote",cascade = CascadeType.ALL)
    @JsonManagedReference
    private UmberllaPreniumCal umpre;
    private double status=1;
    @ManyToOne
    @JoinColumn(name = "insured_id", nullable = false)
    @JsonBackReference
    private Insured insured; // Reference to the Insured entity
}
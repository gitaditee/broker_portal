package com.example.entities;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonManagedReference;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import lombok.Data;
@Entity
@Data
public class UmberllaPreniumCal {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    private double coverage;
    private double percent;
    private double base_prenium;
    private double total_pernium;

//    @OneToOne
//    @JoinColumn(name = "insured_id", nullable = false) // Foreign key reference to Insured
//    private Insured insured; // Link to Insured entity
    @OneToOne
    @JoinColumn(name = "quote")
    @JsonBackReference
    private Quote quote;
}

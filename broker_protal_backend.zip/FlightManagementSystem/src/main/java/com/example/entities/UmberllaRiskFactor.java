package com.example.entities;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonManagedReference;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import lombok.Data;
@Entity
@Data
public class UmberllaRiskFactor {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id; 
    
    private double hasswimmingpool;
    private double haspets;
    private double haskids;
    private double isfrequent_guest;
    private double ageof_home;
    private double onrent;
    private double totalfactor;

    @OneToOne
    @JoinColumn(name = "quote")
    @JsonBackReference
    private Quote quote;
}
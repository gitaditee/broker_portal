package com.example.entities;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonManagedReference;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import lombok.Data;
@Entity
@Data
public class UmberllaCoverage {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;  
    private double bodily_injured;
    private double property_damage;
    private double landlord_liablity;
    private double dog_bite;
    private double total_factor;
    @OneToOne
    @JoinColumn(name = "quote")
   @JsonBackReference
    private Quote quote;
//    @OneToOne
//    @JoinColumn(name = "insured_id", nullable = false)
//    private Insured insured; // Reference to the Insured entity
}
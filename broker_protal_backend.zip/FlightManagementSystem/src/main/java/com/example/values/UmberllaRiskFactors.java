package com.example.values;

import lombok.Data;

@Data
public class UmberllaRiskFactors {
	private boolean hasswimmingpool;
	private boolean haspets;
	private boolean haskids;
	private boolean isfrequent_guest;
	private boolean ageof_home;
	private boolean onrent;
//	public boolean isHasswimmingpool() {
//		return hasswimmingpool;
//	}
//	public boolean isHaspets() {
//		return haspets;
//	}
//	public boolean isHaskids() {
//		return haskids;
//	}
//	public boolean isIsfrequent_guest() {
//		return isfrequent_guest;
//	}
//	public boolean isAgeof_home() {
//		return ageof_home;
//	}
//	public boolean isOnrent() {
//		return onrent;
//	}
//	public void setHasswimmingpool(boolean hasswimmingpool) {
//		this.hasswimmingpool = hasswimmingpool;
//	}
//	public void setHaspets(boolean haspets) {
//		this.haspets = haspets;
//	}
//	public void setHaskids(boolean haskids) {
//		this.haskids = haskids;
//	}
//	public void setIsfrequent_guest(boolean isfrequent_guest) {
//		this.isfrequent_guest = isfrequent_guest;
//	}
//	public void setAgeof_home(boolean ageof_home) {
//		this.ageof_home = ageof_home;
//	}
//	public void setOnrent(boolean onrent) {
//		this.onrent = onrent;
//	}
}

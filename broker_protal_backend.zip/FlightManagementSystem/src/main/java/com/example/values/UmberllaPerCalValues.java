package com.example.values;

import lombok.Data;

@Data
public class UmberllaPerCalValues {
	private double coverage;
	private double percent;
	private double base_prenium;
	private double total_pernium;
}

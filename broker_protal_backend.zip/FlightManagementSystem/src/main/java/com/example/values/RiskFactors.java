package com.example.values;

import lombok.Data;

@Data
public class RiskFactors {
	
	private boolean forbusiness;
	private boolean inconstrn;
	private boolean poorcodn;
	private boolean unoccupied;
	private boolean hostels;
	private boolean alarm;
//	public boolean isForbusiness() {
//		return forbusiness;
//	}
//	public boolean isInconstrn() {
//		return inconstrn;
//	}
//	public boolean isPoorcodn() {
//		return poorcodn;
//	}
//	public boolean isUnoccupied() {
//		return unoccupied;
//	}
//	public boolean isHostels() {
//		return hostels;
//	}
//	public boolean isAlarm() {
//		return alarm;
//	}
//	public void setForbusiness(boolean forbusiness) {
//		this.forbusiness = forbusiness;
//	}
//	public void setInconstrn(boolean inconstrn) {
//		this.inconstrn = inconstrn;
//	}
//	public void setPoorcodn(boolean poorcodn) {
//		this.poorcodn = poorcodn;
//	}
//	public void setUnoccupied(boolean unoccupied) {
//		this.unoccupied = unoccupied;
//	}
//	public void setHostels(boolean hostels) {
//		this.hostels = hostels;
//	}
//	public void setAlarm(boolean alarm) {
//		this.alarm = alarm;
//	}
//	
}
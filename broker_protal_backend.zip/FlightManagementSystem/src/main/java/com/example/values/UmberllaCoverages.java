package com.example.values;

import lombok.Data;

@Data
public class UmberllaCoverages {
	private boolean bodily_injured;
	private boolean property_damage;
	private boolean landlord_liablity;
	private boolean dog_bite;
}

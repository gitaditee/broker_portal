package com.example.dto;

import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.Data;
@Data
public class QuoteDto {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    
    private long rfid;
    private long hmoid;
    private long umrfid;
    private long umcvid;
    private long umprid;
    private String status;
    // Fields for UmberllaPreniumCal details
    private double coverage;
    private double percent;
    private double basePremium;
    private double totalPremium;

  
}
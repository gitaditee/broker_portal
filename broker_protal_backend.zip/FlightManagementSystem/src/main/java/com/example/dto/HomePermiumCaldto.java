package com.example.dto;

import lombok.Data;

@Data
public class HomePermiumCaldto {
	private long quoteid;
	private double coverage;
	private double base_rate;
	private int base_prenium;
	private int total_pernium;
}

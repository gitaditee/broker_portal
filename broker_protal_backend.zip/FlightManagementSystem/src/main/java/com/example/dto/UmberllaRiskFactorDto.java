package com.example.dto;

import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.Data;

@Data
public class UmberllaRiskFactorDto {
	private long quoteid;
	private double hasswimmingpool;
	private double haspets;
	private double haskids;
	private double isfrequent_guest;
	private double ageof_home;
	private double onrent;
}

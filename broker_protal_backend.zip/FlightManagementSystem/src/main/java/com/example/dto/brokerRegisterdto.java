package com.example.dto;

import java.util.List;

import com.example.entities.Insured;

import lombok.Data;

@Data
public class brokerRegisterdto {
	private long id;
	private String email;
	private String password;
	private String name;
	private String role;
	private List<Insured> insured;
}

package com.example.dto;

import lombok.Data;

@Data
public class UmberllaCoveragedto {
	private long quoteid;
	private double bodily_injured;
	private double property_damage;
	private double landlord_liablity;
	private double dog_bite;
}

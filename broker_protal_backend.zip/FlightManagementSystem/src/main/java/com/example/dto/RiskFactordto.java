package com.example.dto;

import lombok.Data;

@Data
public class RiskFactordto {
	private long quoteid;
	private double forbusiness;
	private double inconstrn;
	private double poorcodn;
	private double unoccupied;
	private double hostels;
	private double alarm;
	private double totalfactor;
	
}

package com.example.dto;

import java.util.Date;

import com.example.entities.Broker;

import lombok.Data;
@Data
public class InsuredDto {
	
	
	private String name;
	private String occupation;
	private Date startdate;
	private Date enddate;
	private long brokerid;
	
}

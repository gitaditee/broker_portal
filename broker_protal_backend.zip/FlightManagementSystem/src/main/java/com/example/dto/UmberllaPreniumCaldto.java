package com.example.dto;

import lombok.Data;

@Data
public class UmberllaPreniumCaldto {
	private long quoteid;
	private double coverage;
	private double percent;
	private double base_prenium;
	private double total_pernium;
}

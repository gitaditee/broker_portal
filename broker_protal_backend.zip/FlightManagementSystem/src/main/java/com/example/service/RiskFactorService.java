package com.example.service;
import com.example.dto.*;
public interface RiskFactorService {
	public void saveRiskFactor(RiskFactordto fdto);
	public double calmultiplier(Long id);
}

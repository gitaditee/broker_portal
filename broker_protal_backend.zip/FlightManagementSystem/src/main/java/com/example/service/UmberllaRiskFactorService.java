package com.example.service;

import com.example.dto.UmberllaRiskFactorDto;

public interface UmberllaRiskFactorService {
	 public void saveRiskFactors( UmberllaRiskFactorDto umrfdto);
	  public double calculateRiskMultiplier(Long quoteid) ;
}

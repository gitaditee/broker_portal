package com.example.service;

import com.example.dto.InsuredDto;
import com.example.entities.Quote;

public interface InsuredService {
	public long saveinsuredWithQuote(InsuredDto insuredDto);
	public void deleteCustomer(long insuredId);

}

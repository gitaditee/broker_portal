package com.example.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.dto.UmberllaRiskFactorDto;
import com.example.entities.Insured;
import com.example.entities.Quote;
import com.example.entities.RiskFactor;
import com.example.entities.UmberllaRiskFactor;
import com.example.repository.InsuredRepo;
import com.example.repository.QuoteRepo;
import com.example.repository.UmberllaRiskFactorRepo;
@Service
public class UmberllaInterfaceServiceImpl implements UmberllaRiskFactorService {

    @Autowired
    private UmberllaRiskFactorRepo umrepo;

    @Autowired
    private QuoteRepo quoterepo;
    @Override
    public void saveRiskFactors( UmberllaRiskFactorDto umrfdto) {
        // Fetch the insured by ID to link the risk factor
    	  Quote quote = quoterepo.findById(umrfdto.getQuoteid())
                  .orElseThrow(() -> new RuntimeException("Quote not found with ID: " + umrfdto.getQuoteid()));

        UmberllaRiskFactor umrf = new UmberllaRiskFactor();
        
        umrf.setHaskids(umrfdto.getHaskids());
        umrf.setHaspets(umrfdto.getHaspets());
        umrf.setHasswimmingpool(umrfdto.getHasswimmingpool());
        umrf.setIsfrequent_guest(umrfdto.getIsfrequent_guest());
        umrf.setOnrent(umrfdto.getOnrent());
        umrf.setQuote(quote);
       umrepo.save(umrf);      
    }

    @Override
    public double calculateRiskMultiplier(Long quoteid) {
        // Fetch UmbrellaRiskFactor by Insured ID
       UmberllaRiskFactor umrfcal = umrepo.findByQuoteId(quoteid)
                .orElseThrow(() -> new RuntimeException("Risk factors not found for insured ID: " + quoteid));

        // Calculate the multiplier using the risk factor fields
        double multiplier = (umrfcal.getHaskids() +
                            umrfcal.getHaspets() +
                            umrfcal.getHasswimmingpool() +
                            umrfcal.getIsfrequent_guest() +
                            umrfcal.getOnrent())/6;

        // Update total factor in the database
        umrfcal.setTotalfactor(multiplier);
        umrepo.save(umrfcal);

        // Return the calculated multiplier
        return multiplier;
    }
}
package com.example.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.dto.InsuredDto;
import com.example.dto.brokerRegisterdto;
import com.example.entities.Broker;
import com.example.entities.Insured;
import com.example.entities.Quote;
import com.example.repository.BrokerRepo;
import com.example.repository.InsuredRepo;
import com.example.repository.QuoteRepo;
@Service
public class InsuredServiceImpl implements InsuredService {
    @Autowired
    private BrokerRepo brepo;
    @Autowired
    private InsuredRepo insrepo;
    @Autowired
    private QuoteRepo quoteRepo;
    @Override
    public long saveinsuredWithQuote(InsuredDto insuredDto) {
        Broker broker = brepo.findById(insuredDto.getBrokerid())
                .orElseThrow(() -> new RuntimeException("Broker not found for ID: " + insuredDto.getBrokerid()));
        Insured insured = new Insured();
        insured.setName(insuredDto.getName());
        insured.setOccupation(insuredDto.getOccupation());
        insured.setStartdate(insuredDto.getStartdate());
        insured.setEnddate(insuredDto.getEnddate());
        insured.setBroker(broker);
        insured = insrepo.save(insured);  // Save the new insured
        long insuredid=insured.getId();
        return insuredid;
    }
  
    public List<Quote> getQuotesByInsuredId(long insuredId) {
        Insured insured = insrepo.findById(insuredId)
                .orElseThrow(() -> new RuntimeException("Insured not found with ID: " + insuredId));
        return insured.getQuotes();
    }

   public void deleteCustomer(long insuredId) {
	   Insured insured = insrepo.findById(insuredId)
               .orElseThrow(() -> new RuntimeException("Insured not found with ID: " + insuredId));
	  insrepo.deleteById(insuredId);
   }
}
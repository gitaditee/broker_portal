package com.example.service;

import com.example.entities.HomePermiumCal;

public interface HomePermiumCalService {
	//public void saveid(long id);
	public HomePermiumCal saveCoverage(double coverage, long quoteid);
	public double calbaseper(long quoteid, long riskFactorId);
	public HomePermiumCal saveHomeCoverage(double coverage, long quoteId) ;
}

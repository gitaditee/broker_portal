package com.example.service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.example.repository.HomePremiumCalRepo;
import com.example.repository.InsuredRepo;
import com.example.repository.QuoteRepo;
import com.example.repository.RiskFactorRepo;
import com.example.entities.HomePermiumCal;
import com.example.entities.Insured;
import com.example.entities.Quote;
import com.example.entities.RiskFactor;
@Service
public class HomePermiumCalImpl implements HomePermiumCalService {

    @Autowired
    private HomePremiumCalRepo homePremiumRepo;

    @Autowired
    private QuoteRepo quoterepo; 

    @Autowired
    private RiskFactorRepo riskFactorRepo;

    public HomePermiumCal saveCoverage(double coverage, long quoteid) {
        
        Quote quote = quoterepo.findById(quoteid)
                .orElseThrow(() -> new RuntimeException("Insured not found with ID: " + quoteid));

        HomePermiumCal homePremium = homePremiumRepo.findByQuoteId(quoteid).orElse(null);

        if (homePremium == null) {
            
            homePremium = new HomePermiumCal();
           
        }
        
        homePremium.setCoverage(coverage);
        homePremium.setQuote(quote);
        homePremiumRepo.save(quote);
        
        return homePremiumRepo.save(homePremium);
    }
    @Override
    public double calbaseper(long quoteid, long riskFactorId) {
       
        HomePermiumCal homePremium = homePremiumRepo.findByQuoteId(quoteid)
                .orElseThrow(() -> new RuntimeException("Home Premium Calculation not found for quote ID: " + quoteid));

        double clientCoverage = homePremium.getCoverage();
        double basePremium = clientCoverage * 0.01;
        homePremium.setBase_prenium(basePremium);

        RiskFactor riskFactor = riskFactorRepo.findById(riskFactorId)
                .orElseThrow(() -> new RuntimeException("Risk Factor not found for riskFactor ID: " + riskFactorId));

        double multiplier = riskFactor.getTotalfactor();
        double totalPremium = basePremium * multiplier;
        homePremium.setTotal_pernium(totalPremium);

        homePremiumRepo.save(homePremium);

        return totalPremium;
    }
    @Override
    public HomePermiumCal saveHomeCoverage(double coverage, long quoteId) {
        // Check if the Quote exists
        Quote quote = quoterepo.findById(quoteId)
                .orElseThrow(() -> new RuntimeException("Insured not found with ID: " + quoteId));

        // Check if the HomePremium exists or create a new one
        HomePermiumCal homePremium = homePremiumRepo.findByQuoteId(quoteId)
                .orElse(new HomePermiumCal());  // If not found, create a new one

        homePremium.setQuote(quote);
        homePremium.setCoverage(coverage);

        // Save the HomePremium instance
        HomePermiumCal savedPremium = homePremiumRepo.save(homePremium);

        // Return the saved premium instance to the frontend
        return savedPremium;
    }
}
package com.example.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.dto.UmberllaPreniumCaldto;
import com.example.entities.HomePermiumCal;
import com.example.entities.Quote;
import com.example.entities.UmberllaCoverage;
import com.example.entities.UmberllaPreniumCal;
import com.example.entities.UmberllaRiskFactor;
import com.example.repository.HomePremiumCalRepo;
import com.example.repository.QuoteRepo;
import com.example.repository.UmberllaCoverageRepo;
import com.example.repository.UmberllaPremiumRepo;
import com.example.repository.UmberllaRiskFactorRepo;

@Service
public class UmberllaPreImpl implements UmberllaPreService {

    @Autowired
    private HomePremiumCalRepo homeRepo;
    @Autowired
    private UmberllaPremiumRepo umPremiumRepo;
    @Autowired
    private UmberllaRiskFactorRepo umRiskFactorRepo;
    @Autowired
    private UmberllaCoverageRepo umcvrepo;
    @Autowired
    private QuoteRepo quoteRepository;
    @Override
    public double calculatePremium(Long quoteId, Long riskId,Long covId, UmberllaPreniumCaldto umDto) {
        
        HomePermiumCal homePremiumCal = homeRepo.findByQuoteId(quoteId)
                .orElseThrow(() -> new RuntimeException("HomePremium not found with Quote ID: " + quoteId));

        Quote quote = quoteRepository.findById(quoteId)
                .orElseThrow(() -> new RuntimeException("Quote not found with ID: " + quoteId));

        // Create a new UmbrellaPremiumCal object
        UmberllaPreniumCal umPremiumCal = new UmberllaPreniumCal();

        double coverage = homePremiumCal.getCoverage();
        umPremiumCal.setPercent(umDto.getPercent());
        double homeprenium=homePremiumCal.getTotal_pernium();
        double percent = umDto.getPercent();
        double umbrellaCoverage = coverage;

        // Calculate umbrella coverage based on percent
        if (percent == 20) {
            umbrellaCoverage = coverage + (coverage * 0.2);
        } else if (percent == 30) {
            umbrellaCoverage = coverage + (coverage * 0.3);
        } else if (percent == 40) {
            umbrellaCoverage = coverage + (coverage * 0.4);
        } else if (percent == 50) {
            umbrellaCoverage = coverage + (coverage * 0.5);
        } else {
            throw new RuntimeException("Invalid percentage value!");
        }

        // Associate UmbrellaPremiumCal with Quote
        umPremiumCal.setQuote(quote);
        umPremiumCal.setBase_prenium(umbrellaCoverage);
        System.out.println("coverage after adding %"+  umbrellaCoverage);
        // Save UmbrellaPremiumCal
        umPremiumRepo.save(umPremiumCal);

        // Fetch risk factor using riskId
        UmberllaRiskFactor umRiskFactor = umRiskFactorRepo.findById(riskId)
                .orElseThrow(() -> new RuntimeException("Risk factor not found!"));
        double riskFactorTotal = umRiskFactor.getTotalfactor();
        UmberllaCoverage umcv=umcvrepo.findById(covId).orElseThrow(() -> new RuntimeException("coverage factor not found!"));
        double coveragetotal=umcv.getTotal_factor();
        // Calculate total premium
        umbrellaCoverage = umbrellaCoverage + coveragetotal;
        double base_prenium=umbrellaCoverage*0.01;
        double UmbrellaPremium = (base_prenium * riskFactorTotal);
        System.out.println("after adding all multiplier"+UmbrellaPremium);
        // all over prenium
        double totalPremium=UmbrellaPremium+homeprenium;
        System.out.println("total prenium"+totalPremium);
        //add gst
        double totalUmbrellaPremium=totalPremium + (totalPremium * 18)/100;
        System.out.println("adding 18% gst"+totalUmbrellaPremium);
        umPremiumCal.setTotal_pernium(totalUmbrellaPremium);
        umPremiumCal.setCoverage(coveragetotal);
        // Save the updated UmbrellaPremiumCal object
        umPremiumRepo.save(umPremiumCal);

        // Return the total premium
        return totalUmbrellaPremium;
    }
    @Override
    public double calculateonlyUmPremium(Long quoteId, Long riskId,Long covId, UmberllaPreniumCaldto umDto) {
    	HomePermiumCal homePremiumCal = homeRepo.findByQuoteId(quoteId)
                .orElseThrow(() -> new RuntimeException("HomePremium not found with Quote ID: " + quoteId));
    	 Quote quote = quoteRepository.findById(quoteId)
                 .orElseThrow(() -> new RuntimeException("Quote not found with ID: " + quoteId));
    	 UmberllaPreniumCal umPremiumCal = new UmberllaPreniumCal();

         double coverage = homePremiumCal.getCoverage();
         umPremiumCal.setPercent(umDto.getPercent());
         double percent = umDto.getPercent();
         double umbrellaCoverage = coverage;

         // Calculate umbrella coverage based on percent
         if (percent == 20) {
             umbrellaCoverage = coverage + (coverage * 0.2);
         } else if (percent == 30) {
             umbrellaCoverage = coverage + (coverage * 0.3);
         } else if (percent == 40) {
             umbrellaCoverage = coverage + (coverage * 0.4);
         } else if (percent == 50) {
             umbrellaCoverage = coverage + (coverage * 0.5);
         } else {
             throw new RuntimeException("Invalid percentage value!");
         }
         umPremiumCal.setQuote(quote);
         umPremiumCal.setBase_prenium(umbrellaCoverage);
         System.out.println("coverage after adding %"+  umbrellaCoverage);
         // Save UmbrellaPremiumCal
         umPremiumRepo.save(umPremiumCal);
         UmberllaRiskFactor umRiskFactor = umRiskFactorRepo.findById(riskId)
                 .orElseThrow(() -> new RuntimeException("Risk factor not found!"));
         double riskFactorTotal = umRiskFactor.getTotalfactor();
         UmberllaCoverage umcv=umcvrepo.findById(covId).orElseThrow(() -> new RuntimeException("coverage factor not found!"));
         double coveragetotal=umcv.getTotal_factor();
         // Calculate total premium
         umbrellaCoverage = umbrellaCoverage + coveragetotal;
         double base_prenium=umbrellaCoverage*0.01;
         double UmbrellaPremium = (base_prenium * riskFactorTotal);
         System.out.println("after adding all multiplier"+UmbrellaPremium);
         double totalUmbrellaPremium=UmbrellaPremium+ (UmbrellaPremium * 18)/100;
         System.out.println("adding 18% gst"+totalUmbrellaPremium);
         umPremiumCal.setTotal_pernium(totalUmbrellaPremium);
         umPremiumCal.setCoverage(coveragetotal);
         // Save the updated UmbrellaPremiumCal object
         umPremiumCal = umPremiumRepo.save(umPremiumCal);
        
    	return totalUmbrellaPremium;
    }
    
}

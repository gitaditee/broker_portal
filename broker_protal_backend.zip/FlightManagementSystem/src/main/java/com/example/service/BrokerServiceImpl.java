package com.example.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.dto.brokerRegisterdto;
import com.example.entities.*;
import com.example.repository.*;

@Service
public class BrokerServiceImpl implements BrokerService{
	@Autowired
	BrokerRepo brepo;
	
	@Override
	public void registerUser(brokerRegisterdto bdto) {
		// TODO Auto-generated method stub
		Broker broker = new Broker();
		broker.setEmail(bdto.getEmail());
		broker.setPassword(bdto.getPassword());
		broker.setName(bdto.getName());
		brepo.save(broker);
	}
	
	    public Broker loginUser(brokerRegisterdto bdto) {
	        Broker broker =brepo.findByEmail(bdto.getEmail());
	        
	        if (broker != null && broker.getPassword().equals(bdto.getPassword())) {
	            return broker;
	        }
	        
	        return null;
	    }
	

    public List<Insured> getInsuredByBrokerId(long brokerId) {
        Broker broker = brepo.findById(brokerId)
                                         .orElseThrow(() -> new RuntimeException("Broker not found"));
        return broker.getInsured();
    }

}

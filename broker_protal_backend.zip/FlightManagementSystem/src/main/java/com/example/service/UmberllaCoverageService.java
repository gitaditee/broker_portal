package com.example.service;

import com.example.dto.UmberllaCoveragedto;

public interface UmberllaCoverageService {
	public void saveriskfactors(UmberllaCoveragedto umcvdto);
	 public double calmultiplier(Long quoteid);
}

package com.example.service;

import com.example.dto.QuoteDto;
import com.example.entities.Quote;

public interface QuoteService {
	  public Quote createQuote(Long insuredId);
	 public QuoteDto getQuoteDetails(long quoteId);
	 public QuoteDto setStatusquote(long quoteid,double st);
}

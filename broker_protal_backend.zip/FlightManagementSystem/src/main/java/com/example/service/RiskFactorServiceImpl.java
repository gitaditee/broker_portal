package com.example.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.dto.RiskFactordto;
import com.example.entities.Insured;
import com.example.entities.Quote;
import com.example.entities.RiskFactor;
import com.example.repository.InsuredRepo;
import com.example.repository.RiskFactorRepo;
import com.example.repository.QuoteRepo;
@Service
public class RiskFactorServiceImpl implements RiskFactorService {

    @Autowired
    private RiskFactorRepo rfrepo;

    @Autowired
    private QuoteRepo quoteRepo;
   
    @Override
    public void saveRiskFactor(RiskFactordto fdto) {
        
        Quote quote = quoteRepo.findById(fdto.getQuoteid())
                .orElseThrow(() -> new RuntimeException("Insured not found with id: " + fdto.getQuoteid()));

        RiskFactor rf = new RiskFactor();
        rf.setForbusiness(fdto.getForbusiness());
        rf.setInconstrn(fdto.getInconstrn());
        rf.setPoorcodn(fdto.getPoorcodn());
        rf.setUnoccupied(fdto.getUnoccupied());
        rf.setHostels(fdto.getHostels());
        rf.setAlarm(fdto.getAlarm());
        rf.setQuote(quote);

        rfrepo.save(rf);
    }

    @Override
    public double calmultiplier(Long quoteid) {
    	 RiskFactor rf = new RiskFactor();
        RiskFactor rfcal = rfrepo.findByQuoteId(quoteid)
                .orElseThrow(() -> new RuntimeException("RiskFactor not found for insured id: " + quoteid));

        double multipler = (rfcal.getForbusiness() +rfcal.getHostels() + rfcal.getInconstrn()
                + rfcal.getPoorcodn() + rfcal.getUnoccupied())/5;

        rfcal.setTotalfactor(multipler);
        rfrepo.save(rfcal);
        int rfid=rf.getId();
        return multipler;
    }
}
package com.example.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.dto.HomePermiumCaldto;
import com.example.dto.QuoteDto;
import com.example.dto.RiskFactordto;
import com.example.entities.HomePermiumCal;
import com.example.entities.Insured;
import com.example.entities.Quote;
import com.example.entities.RiskFactor;
import com.example.entities.UmberllaCoverage;
import com.example.entities.UmberllaPreniumCal;
import com.example.entities.UmberllaRiskFactor;
import com.example.repository.HomePremiumCalRepo;
import com.example.repository.InsuredRepo;
import com.example.repository.QuoteRepo;
import com.example.repository.RiskFactorRepo;
import com.example.repository.UmberllaCoverageRepo;
import com.example.repository.UmberllaPremiumRepo;
import com.example.repository.UmberllaRiskFactorRepo;
@Service
public class QuoteServiceImpl implements QuoteService {

    @Autowired
    private QuoteRepo quoteRepository;

    @Autowired
    private RiskFactorRepo riskFactorRepo;

    @Autowired
    private HomePremiumCalRepo homePremiumRepo;

    @Autowired
    private UmberllaRiskFactorRepo umrfrepo;

    @Autowired
    private UmberllaCoverageRepo umcvrepo;

    @Autowired
    private UmberllaPremiumRepo umprerepo;
    @Autowired
    private InsuredRepo insuredRepo;

    @Override
    public Quote createQuote(Long insuredId) {
    	Insured insured = insuredRepo.findById(insuredId).orElseThrow(() -> new RuntimeException("Insured not found with ID: " + insuredId));

        Quote quote = new Quote();
        
        quote.setInsured(insured);

        return quoteRepository.save(quote);
    }
        @Override
        public QuoteDto getQuoteDetails(long quoteId) {
            
            Quote quote = quoteRepository.findById(quoteId)
                    .orElseThrow(() -> new RuntimeException("Quote not found with ID: " + quoteId));

            QuoteDto quoteDto = new QuoteDto();
            quoteDto.setId(quote.getId());
            quoteDto.setRfid(quote.getRiskFactors().getId());
            quoteDto.setHmoid(quote.getHomePremiumDetails().getId());
            quoteDto.setUmrfid(quote.getUmrf().getId());
            quoteDto.setUmcvid(quote.getUmcv().getId());
            quoteDto.setUmprid(quote.getUmpre().getId());

            quoteDto.setCoverage(quote.getUmpre().getCoverage());
            quoteDto.setPercent(quote.getUmpre().getPercent());
            quoteDto.setBasePremium(quote.getUmpre().getBase_prenium());
            quoteDto.setTotalPremium(quote.getUmpre().getTotal_pernium());

            return quoteDto;
        }
        @Override
        public QuoteDto setStatusquote(long quoteid,double st) {
        	Quote quote = quoteRepository.findById(quoteid)
                    .orElseThrow(() -> new RuntimeException("Quote not found with ID: " + quoteid));
        	 QuoteDto quoteDto = new QuoteDto();
        	if(st==1) {
        		quoteDto.setStatus("approved");
        	}
        	else if(st==2) {
        		quoteDto.setStatus("pending");
        	}
        	else if(st==3) {
        		quoteDto.setStatus("decline");
        	}
        	quote.setStatus(quoteid);
        	return quoteDto;
        }
    
}

package com.example.service;

import com.example.entities.Broker;
import com.example.entities.Insured;

import java.util.List;

import com.example.dto.brokerRegisterdto;
public interface BrokerService {
	public void registerUser(brokerRegisterdto bdto);
	 public Broker loginUser(brokerRegisterdto bdto);
	public List<Insured> getInsuredByBrokerId(long id);
}
package com.example.service;

import com.example.dto.UmberllaPreniumCaldto;

public interface UmberllaPreService {
	public double calculatePremium(Long quoteId, Long riskId,Long covId, UmberllaPreniumCaldto umDto);
public double calculateonlyUmPremium(Long quoteId, Long riskId,Long covId, UmberllaPreniumCaldto umDto) ;
}

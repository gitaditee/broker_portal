package com.example.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.dto.UmberllaCoveragedto;
import com.example.dto.UmberllaRiskFactorDto;
import com.example.entities.UmberllaCoverage;
import com.example.entities.UmberllaRiskFactor;
import com.example.repository.UmberllaCoverageRepo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.dto.UmberllaCoveragedto;
import com.example.entities.UmberllaCoverage;
import com.example.entities.Insured;
import com.example.entities.Quote;
import com.example.repository.UmberllaCoverageRepo;
import com.example.repository.InsuredRepo;
import com.example.repository.QuoteRepo;

@Service
public class UmberllaCoverageImpl implements UmberllaCoverageService {

    @Autowired
    private UmberllaCoverageRepo umcvrepo;

    @Autowired
    private QuoteRepo quoterepo; 

    @Override
    public void saveriskfactors(UmberllaCoveragedto umcvdto) {
        // Fetch Insured by ID
        Quote quote = quoterepo.findById(umcvdto.getQuoteid())
                .orElseThrow(() -> new RuntimeException("Insured not found with ID: " + umcvdto.getQuoteid()));

        UmberllaCoverage umcv = new UmberllaCoverage();
        umcv.setBodily_injured(umcvdto.getBodily_injured());
        umcv.setDog_bite(umcvdto.getDog_bite());
        umcv.setLandlord_liablity(umcvdto.getLandlord_liablity()); 
        umcv.setProperty_damage(umcvdto.getProperty_damage());
        umcv.setQuote(quote); 
        umcvrepo.save(umcv);
    }

  
    @Override
    public double calmultiplier(Long quoteid) {
        // Fetch UmbrellaCoverage by Insured ID
        UmberllaCoverage umcv = umcvrepo.findByQuoteId(quoteid)
                .orElseThrow(() -> new RuntimeException("Umbrella coverage not found for insured ID: " + quoteid));

        double bodilyInjured = umcv.getBodily_injured(); 
        double dogBite = umcv.getDog_bite();
        double landlordLiability = umcv.getLandlord_liablity();
        double propertyDamage = umcv.getProperty_damage();

        double multiplier = (bodilyInjured + dogBite + landlordLiability + propertyDamage);

        umcv.setTotal_factor(multiplier);
        umcvrepo.save(umcv);

        return multiplier;
    }
}
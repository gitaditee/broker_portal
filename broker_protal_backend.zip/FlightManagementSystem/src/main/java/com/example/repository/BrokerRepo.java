package com.example.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.entities.*;
@Repository
public interface BrokerRepo extends JpaRepository<Broker, Long>{
	Broker findByEmail(String email);	
	Broker findByEmailAndPassword(String email, String password);
}

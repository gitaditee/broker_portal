package com.example.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.entities.HomePermiumCal;
import com.example.entities.Insured;
import com.example.entities.Quote;
@Repository
public interface HomePremiumCalRepo extends JpaRepository<HomePermiumCal, Long> {
    // Automatically derived query based on method name
    Optional<HomePermiumCal> findByQuoteId(Long quoteid);

	void save(Quote quote);
}
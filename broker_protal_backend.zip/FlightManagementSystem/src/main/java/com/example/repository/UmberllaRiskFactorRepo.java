package com.example.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import org.springframework.stereotype.Repository;

import com.example.entities.Quote;
import com.example.entities.UmberllaRiskFactor;
@Repository
public interface UmberllaRiskFactorRepo extends JpaRepository<UmberllaRiskFactor, Long> {
    Optional<UmberllaRiskFactor> findByQuoteId(Long quoteid);

	

	

	//List<UmberllaRiskFactor> findAllByRiskId(Long riskId);
}
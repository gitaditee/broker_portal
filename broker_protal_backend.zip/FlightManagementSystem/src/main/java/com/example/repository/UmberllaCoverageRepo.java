package com.example.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.entities.RiskFactor;
import com.example.entities.UmberllaCoverage;
import com.example.entities.UmberllaPreniumCal;

import org.springframework.data.jpa.repository.JpaRepository;
import com.example.entities.UmberllaCoverage;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import com.example.entities.UmberllaCoverage;
import java.util.Optional;
@Repository
public interface UmberllaCoverageRepo extends JpaRepository<UmberllaCoverage, Long> {
//    Optional<UmberllaCoverage> findByBrokerId(Long brokerId);
	Optional<UmberllaCoverage> findByQuoteId(Long quoteid);
}
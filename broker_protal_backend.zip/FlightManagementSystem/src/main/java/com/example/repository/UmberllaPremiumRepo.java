package com.example.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.entities.UmberllaPreniumCal;
import com.example.entities.UmberllaRiskFactor;
@Repository
public interface UmberllaPremiumRepo extends JpaRepository<UmberllaPreniumCal, Long>{
	 Optional<UmberllaPreniumCal> findByQuoteId(Long quoteid);
}

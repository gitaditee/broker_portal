import { Routes } from '@angular/router';
import { HomePageComponent } from './home-page/home-page.component';
import { SignInComponent } from './sign-in/sign-in.component';
import { SignUpComponent } from './sign-up/sign-up.component';
import { QuoteListPageComponent } from './quote-list-page/quote-list-page.component';
import { QuoteFormComponent } from './quote-form/quote-form.component';
import { UmberllaQuotesComponent } from './umberlla-quotes/umberlla-quotes.component';
import { UmberllaFormComponent } from './umberlla-form/umberlla-form.component';
import { BrokerProfileComponent } from './broker-profile/broker-profile.component';

export const routes: Routes = [
    { path: '', component:HomePageComponent},
    { path:'signin', component:SignInComponent},
    {path:'signup',component:SignUpComponent},
    {path:'quote-list',component:QuoteListPageComponent},
    {path:'quote-form',component:QuoteFormComponent},
   
    {path:'home-details',component:QuoteFormComponent},
    {path:'content-details',component:QuoteFormComponent},
    {path:'cover-details',component:QuoteFormComponent},
    {path:'customize-details',component:QuoteFormComponent},
    {path:'fill-details',component:QuoteFormComponent},
    // {path:'review',component:QuoteFormComponent},
    {path:'umberlla_quote',component:UmberllaQuotesComponent},
    {path:'client-details',component:QuoteListPageComponent},
    {path:'assigned-details',component:QuoteListPageComponent},
    {path:'umberlla-form',component:UmberllaFormComponent},
    {path:'existing-home-details',component:UmberllaFormComponent},
    {path:'umberlla-user-coverage',component:UmberllaFormComponent},
    {path:'broker-profile',component:BrokerProfileComponent},
    {path:'customize-umonly-details',component:UmberllaFormComponent},
    {path:'fill-umonly-details',component:UmberllaFormComponent},
    {path:'all-client-details',component:QuoteListPageComponent}   
];

import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UmberllaFormComponent } from './umberlla-form.component';

describe('UmberllaFormComponent', () => {
  let component: UmberllaFormComponent;
  let fixture: ComponentFixture<UmberllaFormComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [UmberllaFormComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(UmberllaFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

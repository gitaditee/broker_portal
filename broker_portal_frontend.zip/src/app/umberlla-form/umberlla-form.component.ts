import { CommonModule, NgIf } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { NavigationEnd, RouterLink, RouterOutlet } from '@angular/router';
import { NavbarComponent } from '../navbar/navbar.component';
import { NavClientDeComponent } from '../nav-client-de/nav-client-de.component';
import { ActivatedRoute, Router } from '@angular/router';
import { OnlyUmberllaPreniumService } from '../services/only-umberlla-prenium.service';
import { MessageService } from 'primeng/api';
import { ToastModule } from 'primeng/toast';
@Component({
  selector: 'app-umberlla-form',
  imports: [RouterLink, RouterOutlet,FormsModule, CommonModule,ToastModule, NavbarComponent, NavClientDeComponent, NgIf,RouterLink],
  templateUrl: './umberlla-form.component.html',
  standalone: true,
  styleUrl: './umberlla-form.component.css'
})
export class UmberllaFormComponent implements OnInit  {
  activeStepUm: string = 'existing-home-details'; 
  steps: string[] = ['existing-home-details', 'umberlla-user-coverage', 'customize-umonly-details','fill-umonly-details']; // Define available steps

  constructor(private onlyumberlla:OnlyUmberllaPreniumService, private messageService: MessageService,private route: ActivatedRoute, private router: Router) {
    
    if (!this.route.snapshot.url.length) {
      this.router.navigate(['/existing-home-details']); 
    }

    this.router.events.subscribe((event) => {
      if (event instanceof NavigationEnd) {
        const currentPath = this.route.snapshot.url[0]?.path; 
        this.activeStepUm = currentPath && this.steps.includes(currentPath) ? currentPath : 'existing-home-details'; // Default to 'content-details'
      }
    });
  }

  navigateTo(step: string): void {
    if (this.steps.includes(step)) {
      this.router.navigate([step]);
    } else {
      console.error(`Invalid step: ${step}`); 
    }
  }
  // 1)
  goToContentDetails(){
    this.activeStepUm = 'umberlla-user-coverage';
  }

  //2)
  goToCoverDetails(){
    if (!this.coverageAmount || this.coverageAmount < 30000 || this.coverageAmount > 5000000) {
      console.error("Invalid coverage amount:", this.coverageAmount);
      alert("Please enter a valid coverage amount between ₹30,000 and ₹50,00,000.");
      return;
  }
  
  console.log("Selected Coverage Amount:", this.coverageAmount);
  
  // Store coverage amount in localStorage
  localStorage.setItem("coverageAmount", this.coverageAmount.toString());
  
  this.onlyumberlla.getPremium(this.coverageAmount).subscribe({
      next: response => {
          console.log("Full Premium Response:", response);
  
          if (response ) {
            this.messageService.add({
              severity: 'info',
              summary: 'Coverage details',
               detail: `Coverage: ₹${this.coverageAmount}`
             
            });
           
          } else {
              console.error("Premium field missing in response. Check backend.");
          }
      },
      error: error => {
          console.error("Error retrieving premium:", error);
          alert("Failed to get premium. Check console for details.");
      }
  });
  const storedCoverage = localStorage.getItem("coverageAmount");
      this.coverageAmount = storedCoverage ? Number(storedCoverage) : 30000;
      console.log("Retrieved Coverage Amount:", this.coverageAmount); 
      this.messageService.add({
        severity: 'success',
        summary: 'Login Successful',
        detail: `Selected Coverage: ₹${this.coverageAmount}`,
        styleClass: 'custom-toast'
      });
      
      setTimeout(() => {
        this.activeStepUm = 'customize-umonly-details';
      }, 2000); 
  }

  //3)
  coverageSelections: { [key: string]: boolean } = {
    bodily_injured: false,
    property_damage: false,
    landlord_liablity: false,
    dog_bite: false
  };

  ngOnInit() {
      const storedSelections = localStorage.getItem("coverageSelections");
      if (storedSelections) {
          this.coverageSelections = JSON.parse(storedSelections);
      }
  }
  toggleCoverage(coverageType: string) {
    
    this.coverageSelections[coverageType] = !this.coverageSelections[coverageType];
    localStorage.setItem("coverageSelections", JSON.stringify(this.coverageSelections));
    console.log(`Coverage "${coverageType}" toggled:`, this.coverageSelections[coverageType]);
}
  goToFillDetails(){
    localStorage.setItem("coverageSelections", JSON.stringify(this.coverageSelections)); 
      console.log("Stored Coverage Selections:", this.coverageSelections); 
      
      const requestBody = {
        
          coverageSelections: this.coverageSelections
      };
  
      this.onlyumberlla.setCoverages(requestBody)
          .subscribe({
              next: (response) => {
                  console.log("Coverage selections saved successfully!", response);
                  this.messageService.add({
                    severity: 'success',
                    summary: 'Login Successful',
                    detail: `Coverage selections saved successfully!`,
                    styleClass: 'custom-toast'
                  });
                
                  this.fetchCvMultiplier();
                
              },
              error: (error) => {
                  console.error("Error saving coverage selections:", error);
                  alert("Failed to save coverage selections. Please try again.");
              }
          });
  }
 

fetchCvMultiplier() {
  this.onlyumberlla.getMultiplier().subscribe({
      next: response => {
          console.log("Multiplier received from backend:", response);
          if (response?.umcvId) {
              localStorage.setItem("UmcoverageId", response.umcvId.toString());
              console.log("Stored Coverage Factor ID:", response.umcvId);
          } else {
              console.error("Coverage ID not found in response.");
          }
      },
      error: error => {
          console.error("Error retrieving multiplier:", error);
          alert("Failed to get multiplier. Check console for details.");
      }
  });

  this.activeStepUm = 'fill-umonly-details';
}
  selectCoverage(percentage: number) {
   
    localStorage.setItem("selectedCoveragePercentage", percentage.toString());

    console.log("User selected percentage:", percentage);
    alert(`Selected Coverage: ${percentage}%`);
}
coverageAmount: number = 30000; 

//4)
umberllaInfo = {
  ageof_home: false,
  hasswimmingpool: false,
  haspets: false,
  haskids: false,
  isfrequent_guest: false,
  onrent:false
};
goToUmberlla_quote(){
  console.log("User-selected Home Info before saving:", this.umberllaInfo);
  localStorage.setItem("umberllainfo", JSON.stringify(this.umberllaInfo));
  this.messageService.add({
    severity: 'success',
    summary: 'Login Successful',
    detail: `Umberlla information saved successfully!`,
    styleClass: 'custom-toast'
  });
  

  this.onlyumberlla.saveUmberllaInfo(this.umberllaInfo).subscribe({
      next: response => {
          console.log("Home info stored in backend:", response);
          this.fetchRfMultiplier();

          // Retrieve selected percentage before calling getPremium()
          const selectedCoveragePercentage = localStorage.getItem("selectedCoveragePercentage");

          if (!selectedCoveragePercentage) {
              console.error("No selected coverage percentage found in localStorage!");
              alert("Please select a coverage percentage before proceeding.");
              return;
          }

          // Call getPremium() after saving home info
          this.onlyumberlla.getUmPremium(parseFloat(selectedCoveragePercentage)).subscribe({
              next: premiumResponse => {
                  console.log("Calculated Premium:", premiumResponse);
              },
              error: premiumError => {
                  console.error("Error calculating premium:", premiumError);
                  alert("Failed to retrieve premium. Please check console for details.");
              }
          });

          this.router.navigate(['/umberlla_quote']);
      },
      error: error => {
          console.error("Error saving home info in backend:", error);
          alert("Failed to save home info in backend. Check console for details.");
      }
  });
}
fetchRfMultiplier() {
  this.onlyumberlla.getRfMultiplier().subscribe({
      next: response => {
          console.log("Multiplier received from backend:", response);

          // Save riskFactorId in local storage
          if (response?.umrfId) {
              localStorage.setItem("UmRiskFactorId", response.umrfId.toString());
              console.log("Stored Risk Factor ID:", response.umrfId);
          } else {
              console.error("Risk Factor Id not found in response.");
          }

          //alert(`Multiplier value: ${response.multiplier}`);
      },
      error: error => {
          console.error("Error retrieving multiplier:", error);
          alert("Failed to get multiplier. Check console for details.");
      }
  });
}
}

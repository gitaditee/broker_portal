import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { HomePageComponent } from './home-page/home-page.component';
import { SignInComponent } from './sign-in/sign-in.component';
import { SignUpComponent } from './sign-up/sign-up.component';
import { QuoteListPageComponent } from './quote-list-page/quote-list-page.component';
import { NavbarComponent } from './navbar/navbar.component';
import { NavClientDeComponent } from './nav-client-de/nav-client-de.component';
import { NgModel } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { PopupComponent } from './popup/popup.component';
import { UmberllaQuotesComponent } from './umberlla-quotes/umberlla-quotes.component';
import { ReactiveFormsModule } from '@angular/forms';


@Component({
  selector: 'app-root',
  imports: [RouterOutlet,HomePageComponent,SignInComponent,PopupComponent,NavbarComponent,NavClientDeComponent,CommonModule,
    SignUpComponent,CommonModule,QuoteListPageComponent,UmberllaQuotesComponent,ReactiveFormsModule],
   standalone:true,
  templateUrl: './app.component.html',
  
  styleUrl: './app.component.css'
})
export class AppComponent {
  title = 'broker_portal';
}

import { Component, importProvidersFrom, OnInit } from '@angular/core';
import { NavbarComponent } from '../navbar/navbar.component';
import { NavClientDeComponent } from '../nav-client-de/nav-client-de.component';
import { CommonModule } from '@angular/common';
import { NavigationEnd, RouterLink, RouterOutlet } from '@angular/router';
import { ActivatedRoute, Router } from '@angular/router';
import { NgIf } from '@angular/common';
import { UmberllaQuotesComponent } from '../umberlla-quotes/umberlla-quotes.component';
import { FormsModule } from '@angular/forms';
import { HomePreniumService } from '../services/home-prenium.service';
import { UmbrellaPremiumService } from '../services/umberlla-prenium.service';
import { MessageService } from 'primeng/api';
import { ToastModule } from 'primeng/toast';
@Component({
  selector: 'app-quote-form',
  imports: [RouterLink, RouterOutlet,FormsModule, 
    ToastModule,CommonModule, NavbarComponent, NavClientDeComponent, NgIf,RouterLink,RouterOutlet,UmberllaQuotesComponent],
  templateUrl: './quote-form.component.html',
  standalone: true,
  styleUrl: './quote-form.component.css'
})
export class QuoteFormComponent implements OnInit{
  activeStep: string = 'content-details'; 
  steps: string[] = ['home-details', 'content-details', 'cover-details', 'customize-details', 'fill-details', 'umberlla_quote']; // Define available steps

  constructor(private homePreniumService:HomePreniumService,private messageService: MessageService, private umberllaPreniumService:UmbrellaPremiumService,private route: ActivatedRoute, private router: Router) {
    
    if (!this.route.snapshot.url.length) {
      this.router.navigate(['/home-details']); 
    }
    this.router.events.subscribe((event) => {
      if (event instanceof NavigationEnd) {
        const currentPath = this.route.snapshot.url[0]?.path; 
        this.activeStep = currentPath && this.steps.includes(currentPath) ? currentPath : 'home-details'; // Default to 'content-details'
      }
    });
  }

  navigateTo(step: string): void {
    if (this.steps.includes(step)) {
      this.router.navigate([step]);
    } else {
      console.error(`Invalid step: ${step}`); 
    }
  }

  homeInfo = {
    forbusiness: false,
    inconstrn: false,
    poorcodn: false,
    unoccupied: false,
    hostels: false
};

//fn that will save risk factors of home insr from frontend to backend
goToContentDetails() {
  console.log("User-selected Home Info before saving:", this.homeInfo);
  localStorage.setItem("homeInfo", JSON.stringify(this.homeInfo));
  

  this.homePreniumService.saveHomeInfo(this.homeInfo).subscribe({
      next: response => {
          console.log("Home info stored in backend:", response);
         
          this.messageService.add({
            severity: 'info',
            summary: 'Home info saved in successfully!',
             detail: `Home info saved in  successfully!`
           
          });
          setTimeout(() => {
            this.activeStep = 'content-details';
          }, 2000);
          
          this.fetchMultiplier();
      },
      error: error => {
          console.error("Error saving home info in backend:", error);
          alert("Failed to save home info in backend. Check console for details.");
      }
  });
  
}
// it will fetch multiplier and than used for further calculations
fetchMultiplier() {
  this.homePreniumService.getMultiplier().subscribe({
      next: response => {
          console.log("Multiplier received from backend:", response);

          if (response?.riskFactorId) {
              localStorage.setItem("riskFactorId", response.riskFactorId.toString());
              console.log("Stored Risk Factor ID:", response.riskFactorId);
          } else {
              console.error("Risk Factor ID not found in response.");
          }
          this.messageService.add({
            severity: 'info',
            summary: 'Values got Set!',
             detail: `Values got Set!`
           
          });
         
      },
      error: error => {
          console.error("Error retrieving multiplier:", error);
          alert("Failed to get multiplier. Check console for details.");
      }
  });
}

  coverageAmount: number = 30000; 
  premiumAmount: number = 0; 
// storing coverage amount from user and saving it in backend for futher cal
  goToCoverDetails() {
      if (!this.coverageAmount || this.coverageAmount < 30000 || this.coverageAmount > 5000000) {
          console.error("Invalid coverage amount:", this.coverageAmount);
          alert("Please enter a valid coverage amount between ₹30,000 and ₹50,00,000.");
          return;
      }

      console.log("Selected Coverage Amount:", this.coverageAmount);
      localStorage.setItem("coverageAmount", this.coverageAmount.toString());

      this.homePreniumService.getPremium(this.coverageAmount).subscribe({
          next: response => {
              console.log("Full Premium Response:", response);

              if (response && response.basePremium) {
                  this.premiumAmount = Math.round(response.basePremium * 100) / 100; // Round to 2 decimal places
                  localStorage.setItem("premiumAmount", this.premiumAmount.toString());
                  this.messageService.add({
                    severity: 'info',
                    summary: 'Coverage details',
                     detail: `Coverage: ₹${this.coverageAmount}, Premium: ₹${this.premiumAmount}`
                   
                  });
                  setTimeout(() => {
                    this.activeStep = 'cover-details';
                  }, 2000);
               
              } else {
                  console.error("Premium field missing in response. Check backend.");
              }
          },
          error: error => {
              console.error("Error retrieving premium:", error);
              alert("Failed to get premium. Check console for details.");
          }
      });

    
  }
 
  
  
  goToCustomizeDetails() {
      const storedCoverage = localStorage.getItem("coverageAmount");
      this.coverageAmount = storedCoverage ? Number(storedCoverage) : 30000;

      const storedPremium = localStorage.getItem("premiumAmount");
      this.premiumAmount = storedPremium ? Number(storedPremium) : 0;

      console.log("Retrieved Coverage Amount:", this.coverageAmount);
      console.log("Retrieved Premium Amount:", this.premiumAmount);
    

      this.activeStep = 'customize-details';
  }
  
    coverageSelections: { [key: string]: boolean } = {
      bodily_injured: false,
      property_damage: false,
      landlord_liablity: false,
      dog_bite: false
    };
   
   
  basePremium: number = 0;
  gstAmount: number = 0;
  totalPremium: number = 0;
  
    
    ngOnInit() {
        const storedSelections = localStorage.getItem("coverageSelections");
        const storedAmount = localStorage.getItem("coverageAmount");
        this.coverageAmount = storedAmount ? Number(storedAmount) : 0;
    
        if (storedSelections) {
            this.coverageSelections = JSON.parse(storedSelections);
        }
    
        const storedPremium = localStorage.getItem("premiumAmount");
    
        if (storedPremium) {
            const premiumAmount = Number(storedPremium); 
    
            // Calculate base premium by removing 18% GST
            this.basePremium = premiumAmount / 1.18;
    
            // Calculate GST amount
            this.gstAmount = premiumAmount - this.basePremium;
    
            this.totalPremium = premiumAmount;
        } else {
            this.basePremium = 0;
            this.gstAmount = 0;
            this.totalPremium = 0;
        }
    }
    toggleCoverage(coverageType: string) {
     
      this.coverageSelections[coverageType] = !this.coverageSelections[coverageType];
      localStorage.setItem("coverageSelections", JSON.stringify(this.coverageSelections));
  
      console.log(`Coverage "${coverageType}" toggled:`, this.coverageSelections[coverageType]);
  }

  //it is set coverage selected by user for umberlla
    goToFillDetails() {
    
      localStorage.setItem("coverageSelections", JSON.stringify(this.coverageSelections));
  
      console.log("Stored Coverage Selections:", this.coverageSelections);
      const requestBody = {
        
          coverageSelections: this.coverageSelections
      };
      this.umberllaPreniumService.setCoverages(requestBody)
          .subscribe({
              next: (response) => {
                  console.log("Coverage selections saved successfully!", response);
                  this.messageService.add({
                    severity: 'info',
                    summary: 'Coverage details',
                     detail: `Coverage selections saved successfully!`
                   
                  });
                  setTimeout(() => {
                    this.activeStep = 'fill-details';
                  }, 2000);
                
                  this.fetchCvMultiplier();
                 
              },
              error: (error) => {
                  console.error("Error saving coverage selections:", error);
                  alert("Failed to save coverage selections. Please try again.");
              }
          });
  }
  // fecthing multiplier of coverages of umberlla
  fetchCvMultiplier() {
    this.umberllaPreniumService.getMultiplier().subscribe({
        next: response => {
            console.log("Multiplier received from backend:", response);
            if (response?.umcvId) {
                localStorage.setItem("UmcoverageId", response.umcvId.toString());
                console.log("Stored Coverage Factor ID:", response.umcvId);
            } else {
                console.error("Coverage ID not found in response.");
            }
        },
        error: error => {
            console.error("Error retrieving multiplier:", error);
            alert("Failed to get multiplier. Check console for details.");
        }
    });
  }
  selectCoverage(percentage: number) {
    localStorage.setItem("selectedCoveragePercentage", percentage.toString());

    console.log("User selected percentage:", percentage);
    this.messageService.add({
        severity: 'info',
        summary: 'Coverage details',
         detail: `Selected Coverage: ${percentage}%`
       
      });
}

umberllaInfo = {
  ageof_home: false,
  hasswimmingpool: false,
  haspets: false,
  haskids: false,
  isfrequent_guest: false,
  onrent:false
};
// fn to save umberlla risk factors
goToUmberlla_quote() {
    console.log("User-selected Home Info before saving:", this.umberllaInfo);
    localStorage.setItem("umberllainfo", JSON.stringify(this.umberllaInfo));
  
    this.umberllaPreniumService.saveUmberllaInfo(this.umberllaInfo).subscribe({
      next: response => {
        console.log("Home info stored in backend:", response);
  
        this.showCustomToast('Coverage details', 'Home info saved in backend successfully!', 'info');
  
        this.fetchRfMultiplier();
  
        const selectedCoveragePercentage = localStorage.getItem("selectedCoveragePercentage");
  
        if (!selectedCoveragePercentage) {
          console.error("No selected coverage percentage found in localStorage!");
          this.showCustomToast('Missing Data', 'Please select a coverage percentage before proceeding.', 'warn');
          return;
        }
        this.umberllaPreniumService.getPremium(parseFloat(selectedCoveragePercentage)).subscribe({
          next: premiumResponse => {
            console.log("Calculated Premium:", premiumResponse);
          },
          error: premiumError => {
            console.error("Error calculating premium:", premiumError);
            this.showCustomToast('Calculation Error', 'Failed to retrieve premium. Please check console for details.', 'error');
          }
        });
  
        this.router.navigate(['/umberlla_quote']);
      },
      error: error => {
        console.error("Error saving home info in backend:", error);
        this.showCustomToast('Backend Error', 'Failed to save home info in backend. Check console for details.', 'error');
      }
    });
  }
  toastMessage: { summary: string; detail: string; severity: string; progress: number } | null = null;
  showToast: boolean = false;
  showCustomToast(summary: string, detail: string, severity: string) {
   
    this.toastMessage = {
      summary: summary,
      detail: detail,
      severity: severity,
      progress: 100 
    };
  
    
    this.showToast = true;
  }

  // fn to save risk multiplier of umberlla coverage
fetchRfMultiplier() {
  this.umberllaPreniumService.getRfMultiplier().subscribe({
      next: response => {
          console.log("Multiplier received from backend:", response);

          if (response?.umrfId) {
              localStorage.setItem("UmRiskFactorId", response.umrfId.toString());
              console.log("Stored Risk Factor ID:", response.umrfId);
          } else {
              console.error("Risk Factor Id not found in response.");
          }

      },
      error: error => {
          console.error("Error retrieving multiplier:", error);
          alert("Failed to get multiplier. Check console for details.");
      }
  });
}
}

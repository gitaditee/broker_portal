import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { catchError, Observable, tap, throwError } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class OnlyUmberllaPreniumService {
  private homecv='http://localhost:8082/homepremium/user-coverage';
  private umbrellaCvUrl = 'http://localhost:8082/umbrella-coverages/set-coverages';
  private umcvmulti='http://localhost:8082/umbrella-coverages/calculate-multiplier';
  private umrfUrl='http://localhost:8082/umbrella-risk-factors/set-risk-factor';
  private umrfMulti='http://localhost:8082/umbrella-risk-factors/calculate-multiplier';
  private umprenium='http://localhost:8082/umbrella-premium-calculator/calculate-um-premium';
  constructor(private http: HttpClient) { }

  //create a quote
  createQuote(insuredId: number): Observable<any> {
    const token = localStorage.getItem('token');
  
    if (!token) {
        console.error('Authentication token missing');
        alert('Please log in again.');
        return throwError(() => new Error('Authentication token missing'));
    }
  
    const headers = new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
    });
  
    const url = `http://localhost:8082/quote/createQuote?insuredId=${insuredId}`;
  
    return this.http.post(url, {}, { headers }).pipe(
      tap(response => {
        const quoteResponse = response as any; // Override TypeScript's strict type checking
        if (quoteResponse?.id) {
            localStorage.setItem("quoteid", quoteResponse.id.toString());
            console.log("Stored Quote ID:", quoteResponse.id);
        } else {
            console.error("Quote ID not found in response.");
        }
    }),
        catchError(error => {
            console.error('Error creating quote:', error);
            alert('Failed to create quote. Check console for details.');
            return throwError(() => error);
        })
    );
  }
  //set coverage
   getPremium(coverage: number): Observable<any> {
      const token = localStorage.getItem('token');
      const quoteId = localStorage.getItem('quoteid');
      if (!token || !quoteId ) {
        console.error('Missing required values in local storage.');
        alert('Token, Quote ID, or Multiplier ID is missing.');
        return throwError(() => new Error('Missing required values'));
    }

    const headers = new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
    });

    const url = `${this.homecv}?coverage=${coverage}&quoteid=${quoteId}`;

    return this.http.post(url, { headers }).pipe(
        tap(response => console.log('Coverage Saved', response)),
        catchError(error => {
            console.error('Error retrieving coverage:', error);
            alert('Failed to get coverage. Check console for details.');
            return throwError(() => error);
        })
    );
}
//set coverages seleceted by user
setCoverages(requestBody: any): Observable<any> {
  // Retrieve quoteId from localStorage
  const token = localStorage.getItem('token');
  const quoteId = localStorage.getItem('quoteid'); // Retrieve quote ID

  if (!token) {
      console.error('Authentication token missing');
      alert('Please log in again.');
      return throwError(() => new Error('Authentication token missing'));
  }

  if (!quoteId) {
      console.error('Quote ID missing from local storage');
      alert('Quote ID is missing. Please generate a quote first.');
      return throwError(() => new Error('Quote ID missing'));
  }
  const headers = new HttpHeaders({
    'Content-Type': 'application/json',
    'Authorization': `Bearer ${token}`
});


  
  const url = `${this.umbrellaCvUrl}?quoteid=${quoteId}`; // Append quote ID in URL

  return this.http.post(url, requestBody, { headers }).pipe(
      tap(response => console.log('Risk factors saved successfully:', response)),
      catchError(error => {
          console.error('Error saving risk factors:', error);
          alert('Failed to save risk factors. Check console for details.');
          return throwError(() => error);
      })
  );
}
//get multiplier of coverage
getMultiplier(): Observable<any> {
const token = localStorage.getItem('token');
const quoteId = localStorage.getItem('quoteid');

if (!token || !quoteId) {
    console.error('Missing token or Quote ID.');
    alert('Authentication or Quote ID is missing.');
    return throwError(() => new Error('Missing token or Quote ID'));
}

const headers = new HttpHeaders({
    'Content-Type': 'application/json',
    'Authorization': `Bearer ${token}`
});

const url = `${this.umcvmulti}?quoteid=${quoteId}`; 

return this.http.post(url, { headers }).pipe(
    tap(response => console.log('Multiplier received:', response)),
    catchError(error => {
        console.error('Error retrieving multiplier:', error);
        alert('Failed to get multiplier. Check console for details.');
        return throwError(() => error);
    })
);
}
//set um risk factors
saveUmberllaInfo(umberllaInfo: any): Observable<any> {
const token = localStorage.getItem('token');
const quoteId = localStorage.getItem('quoteid'); // Retrieve quote ID

if (!token) {
    console.error('Authentication token missing');
    alert('Please log in again.');
    return throwError(() => new Error('Authentication token missing'));
}

if (!quoteId) {
    console.error('Quote ID missing from local storage');
    alert('Quote ID is missing. Please generate a quote first.');
    return throwError(() => new Error('Quote ID missing'));
}

const headers = new HttpHeaders({
    'Content-Type': 'application/json',
    'Authorization': `Bearer ${token}`
});

const url = `${this.umrfUrl}?quoteid=${quoteId}`; // Append quote ID in URL

return this.http.post(url,umberllaInfo, { headers }).pipe(
    tap(response => console.log('Risk factors saved successfully:', response)),
    catchError(error => {
        console.error('Error saving risk factors:', error);
        alert('Failed to save risk factors. Check console for details.');
        return throwError(() => error);
    })
);
}
//get um rf multiplier
getRfMultiplier(): Observable<any> {
const token = localStorage.getItem('token');
const quoteId = localStorage.getItem('quoteid');

if (!token || !quoteId) {
    console.error('Missing token or Quote ID.');
    alert('Authentication or Quote ID is missing.');
    return throwError(() => new Error('Missing token or Quote ID'));
}

const headers = new HttpHeaders({
    'Content-Type': 'application/json',
    'Authorization': `Bearer ${token}`
});

const url = `${this.umrfMulti}?quoteid=${quoteId}`; 

return this.http.post(url, { headers }).pipe(
    tap(response => console.log('Multiplier received:', response)),
    catchError(error => {
        console.error('Error retrieving multiplier:', error);
        alert('Failed to get multiplier. Check console for details.');
        return throwError(() => error);
    })
);
}
//get um prenium
getUmPremium(selectedCoveragePercentage: number): Observable<any> {
const token = localStorage.getItem('token');
const quoteId = localStorage.getItem('quoteid');
const rfid = localStorage.getItem('UmRiskFactorId');
const cvid = localStorage.getItem('UmcoverageId');

if (!token || !quoteId || !rfid || !cvid || !selectedCoveragePercentage) {
    console.error('Missing required values in local storage.');
    alert('Token, Quote ID, Risk Factor ID, Coverage ID, or Selected Coverage Percentage is missing.');
    return throwError(() => new Error('Missing required values'));
}

const headers = new HttpHeaders({
    'Content-Type': 'application/json',
    'Authorization': `Bearer ${token}`
});

// Prepare request body
const requestBody = {
    quoteId: quoteId,
    riskId: rfid,
    coverageId: cvid,
    percent: selectedCoveragePercentage // Correct JSON key structure
};

const url = `${this.umprenium}?quoteid=${quoteId}&riskid=${rfid}&cvid=${cvid}`;

return this.http.post(url, requestBody, { headers }).pipe(
    tap(response => console.log('Premium calculated:', response)),
    catchError(error => {
        console.error('Error retrieving premium:', error);
        alert('Failed to get premium. Check console for details.');
        return throwError(() => error);
    })
);
}
}


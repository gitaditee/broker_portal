import { TestBed } from '@angular/core/testing';
import { AllInsuredServiceService } from './all-insured-service.service';

describe('AllInsuredServiceService', () => {
  let service: AllInsuredServiceService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(AllInsuredServiceService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});

import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AllInsuredServiceService {
  private baseUrl = 'http://localhost:8082/broker/';

  constructor(private http: HttpClient) {}

  getInsuredData(): Observable<any> {
    // Retrieve brokerId from localStorage
    const brokerId = localStorage.getItem('brokerId');
   // console.log("broker id for list",brokerId);
    // Construct the API URL dynamically
    const apiUrl = `${this.baseUrl}${brokerId}/insured`;

    return this.http.get<any>(apiUrl);
  }
}
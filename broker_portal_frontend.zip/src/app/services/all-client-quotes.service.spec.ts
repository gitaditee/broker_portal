import { TestBed } from '@angular/core/testing';
import { AllClientQuotesService } from './all-client-quotes.service';

describe('AllClientQuotesService', () => {
  let service: AllClientQuotesService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(AllClientQuotesService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});

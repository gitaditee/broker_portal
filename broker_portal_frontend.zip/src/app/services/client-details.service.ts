import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, throwError } from 'rxjs';
import { catchError, tap } from 'rxjs/operators';

export interface Broker { 
  name: string;
  occupation: string;
  startdate: Date;
  enddate: Date;
}
@Injectable({
  providedIn: 'root'
})
export class ClientDetailsService {
  private registerUrl = 'http://localhost:8082/add_client/createWithQuote';
  private createquote='http://localhost:8082/quote/createQuote';
  constructor(private http: HttpClient) {}
  saveclient(name: string, occupation: string, startdate: Date, enddate: Date): Observable<any> {
    const body = { name, occupation, startdate, enddate };
    const token = localStorage.getItem('token');
    if (!token) {
        console.error('Authentication token missing');
        alert('Please log in again.');
        return throwError(() => new Error('Authentication token missing'));
    }

    const headers = new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
    });

    return this.http.post(this.registerUrl, body, { headers }).pipe(
        tap(response => console.log('Client saved successfully:', response)),
        catchError(error => {
            console.error('Error occurred:', error);
            alert('Failed to save client. Check console for details.');
            return throwError(() => error);
        })
    );
}
createQuote(insuredId: number): Observable<any> {
  const token = localStorage.getItem('token');

  if (!token) {
      console.error('Authentication token missing');
      alert('Please log in again.');
      return throwError(() => new Error('Authentication token missing'));
  }

  const headers = new HttpHeaders({
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${token}`
  });

  const url = `http://localhost:8082/quote/createQuote?insuredId=${insuredId}`;

  return this.http.post(url, {}, { headers }).pipe(
    tap(response => {
      const quoteResponse = response as any; // Override TypeScript's strict type checking
      if (quoteResponse?.id) {
          localStorage.setItem("quoteid", quoteResponse.id.toString());
          console.log("Stored Quote ID:", quoteResponse.id);
      } else {
          console.error("Quote ID not found in response.");
      }
  }),
      catchError(error => {
          console.error('Error creating quote:', error);
          alert('Failed to create quote. Check console for details.');
          return throwError(() => error);
      })
  );
}
}
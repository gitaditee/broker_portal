import { TestBed } from '@angular/core/testing';

import { BrokerRegisterServiceService } from './broker-register-service.service';
describe('BrokerRegisterServiceService', () => {
  let service: BrokerRegisterServiceService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(BrokerRegisterServiceService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});

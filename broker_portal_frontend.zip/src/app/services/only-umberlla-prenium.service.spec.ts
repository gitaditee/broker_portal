import { TestBed } from '@angular/core/testing';

import { OnlyUmberllaPreniumService } from './only-umberlla-prenium.service';

describe('OnlyUmberllaPreniumService', () => {
  let service: OnlyUmberllaPreniumService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(OnlyUmberllaPreniumService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});

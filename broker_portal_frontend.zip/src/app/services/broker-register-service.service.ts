import { HttpClient, HttpHeaders} from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

export interface Broker { 
  name:String,
  email: string;
  password: string;
}
export interface LoginResponse {
  token?: string; 
  message: string; 
}
@Injectable({
  providedIn: 'root'
})
export class BrokerRegisterServiceService {
  private registerUrl = 'http://localhost:8082/broker/register';
  private loginUrl='http://localhost:8082/broker/login';
  constructor(private http: HttpClient) { }
  
  registerBroker(data:any): Observable<string> {
    return this.http.post(this.registerUrl, data, {
      // headers: {'Content-Type': 'application/json' },
      responseType: 'text', 
    });
  }
  
  loginAdmin(email: string, password: string): Observable<any> {
    const body = { email, password };
    const headers = new HttpHeaders({ 'Content-Type': 'application/json' });
  
    return this.http.post(this.loginUrl, body, {
       headers: {'Content-Type': 'application/json' }
     
    });
  }

}

import { TestBed } from '@angular/core/testing';

import { UmbrellaPremiumService } from './umberlla-prenium.service';
describe('UmberllaPreniumService', () => {
  let service: UmbrellaPremiumService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(UmbrellaPremiumService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});

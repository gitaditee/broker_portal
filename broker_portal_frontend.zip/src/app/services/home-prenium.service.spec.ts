import { TestBed } from '@angular/core/testing';
import { HomePreniumService } from './home-prenium.service';

describe('HomePreniumService', () => {
  let service: HomePreniumService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(HomePreniumService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});

import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AllClientQuotesService {
  
  private baseUrl = 'http://localhost:8082/add_client'; // Base API URL
  private deleteUrl='http:localhost:8082/createWithQuote/deletecustomer/';
  constructor(private http: HttpClient) {}

  getQuotes(insuredid: string): Observable<any[]> {
    const url = `${this.baseUrl}/${insuredid}/quotes`;
    return this.http.get<any[]>(url);
  }
   // Delete customer by ID
   deleteCustomer(insuredId: number): Observable<any> {
    return this.http.delete(`${this.baseUrl}/deletecustomer/${insuredId}`);
  }
// Method to fetch quotes by insuredId
getQuotesByInsuredId(insuredId: number): Observable<any[]> {
  const url = `${this.baseUrl}/${insuredId}/quotes`; // Constructed URL
  return this.http.get<any[]>(url);
}

}
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, throwError } from 'rxjs';
import { catchError, tap } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class HomePreniumService {
  private riskfactorUrl = 'http://localhost:8082/factors/riskfactors';
  private multiplierUrl = 'http://localhost:8082/factors/multipler';
  private preniumURl='http://localhost:8082/homepremium/base_per';
  constructor(private http: HttpClient) {}

  saveHomeInfo(homeInfo: any): Observable<any> {
    const token = localStorage.getItem('token');
    const quoteId = localStorage.getItem('quoteid'); // Retrieve quote ID

    if (!token) {
        console.error('Authentication token missing');
        alert('Please log in again.');
        return throwError(() => new Error('Authentication token missing'));
    }

    if (!quoteId) {
        console.error('Quote ID missing from local storage');
        alert('Quote ID is missing. Please generate a quote first.');
        return throwError(() => new Error('Quote ID missing'));
    }

    const headers = new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
    });

    const url = `${this.riskfactorUrl}?quoteid=${quoteId}`; // Append quote ID in URL

    return this.http.post(url, homeInfo, { headers }).pipe(
        tap(response => console.log('Risk factors saved successfully:', response)),
        catchError(error => {
            console.error('Error saving risk factors:', error);
            alert('Failed to save risk factors. Check console for details.');
            return throwError(() => error);
        })
    );
  }

  getMultiplier(): Observable<any> {
    const token = localStorage.getItem('token');
    const quoteId = localStorage.getItem('quoteid');

    if (!token || !quoteId) {
        console.error('Missing token or Quote ID.');
        alert('Authentication or Quote ID is missing.');
        return throwError(() => new Error('Missing token or Quote ID'));
    }

    const headers = new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
    });

    const url = `${this.multiplierUrl}?quoteid=${quoteId}`;

    return this.http.post(url, { headers }).pipe(
        tap(response => console.log('Multiplier received:', response)),
        catchError(error => {
            console.error('Error retrieving multiplier:', error);
            alert('Failed to get multiplier. Check console for details.');
            return throwError(() => error);
        })
    );
  }
  getPremium(coverage: number): Observable<any> {
    const token = localStorage.getItem('token');
    const quoteId = localStorage.getItem('quoteid');
    const multiplierId = localStorage.getItem('riskFactorId'); // Retrieve multiplier ID

    if (!token || !quoteId || !multiplierId) {
        console.error('Missing required values in local storage.');
        alert('Token, Quote ID, or Multiplier ID is missing.');
        return throwError(() => new Error('Missing required values'));
    }

    const headers = new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
    });

    const url = `${this.preniumURl}?coverage=${coverage}&quoteid=${quoteId}&multiplierId=${multiplierId}`;

    return this.http.post(url, { headers }).pipe(
        tap(response => console.log('Premium calculated:', response)),
        catchError(error => {
            console.error('Error retrieving premium:', error);
            alert('Failed to get premium. Check console for details.');
            return throwError(() => error);
        })
    );
}
}
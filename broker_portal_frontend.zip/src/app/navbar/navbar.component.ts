import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css']
})
export class NavbarComponent {
  brokerName: string = ''; // Add a property for the broker name

  constructor(private router: Router) {
    // Retrieve broker name from localStorage
    const storedBrokerName = localStorage.getItem('brokername');
    this.brokerName = storedBrokerName || 'Broker Name'; // Fallback if no name is stored
    console.log('Broker Name:', this.brokerName);
  }

  gotoQuote() {
    this.router.navigate(['/quote-list']);
  }

  gotobrokerprofile() {
    this.router.navigate(['/broker-profile']);
  }
}
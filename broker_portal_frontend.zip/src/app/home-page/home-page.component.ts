import { Component } from '@angular/core';
import { RouterLink, RouterOutlet } from '@angular/router';
import { SignInComponent } from '../sign-in/sign-in.component';
import { SignUpComponent } from '../sign-up/sign-up.component';

@Component({
  selector: 'app-home-page',
  imports: [RouterLink,RouterOutlet,SignInComponent,SignUpComponent],
  templateUrl: './home-page.component.html',
  styleUrl: './home-page.component.css'
})
export class HomePageComponent {

}

import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-broker-profile',
  imports: [],
  templateUrl: './broker-profile.component.html',
  styleUrl: './broker-profile.component.css'
})

export class BrokerProfileComponent {
  brokerName: string = ''; // Add a property for the broker name
  email :String='';
  constructor(private router: Router) {
    // Retrieve broker name from localStorage
    const storedBrokerName = localStorage.getItem('brokername');
    const brokeremail=localStorage.getItem('brokerEmail');
    this.brokerName = storedBrokerName || 'Broker Name'; // Fallback if no name is stored
    this.email=brokeremail || 'Broker Email';
    console.log('Broker Name:', this.brokerName);
  }
  activeSection: string = 'dashboard'; // Default section

  // Function to set the active section
  setActiveSection(section: string): void {
    this.activeSection = section;
  }
}

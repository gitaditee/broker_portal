import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UmberllaQuotesComponent } from './umberlla-quotes.component';

describe('UmberllaQuotesComponent', () => {
  let component: UmberllaQuotesComponent;
  let fixture: ComponentFixture<UmberllaQuotesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [UmberllaQuotesComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(UmberllaQuotesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

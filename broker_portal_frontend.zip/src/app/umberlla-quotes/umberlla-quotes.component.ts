import { Component, OnInit } from '@angular/core';
import { AllClientQuotesService } from '../services/all-client-quotes.service';
import { NavbarComponent } from '../navbar/navbar.component';
import { CommonModule, NgFor, NgIf } from '@angular/common';
import { Router, RouterLink, RouterOutlet } from '@angular/router';
import { ChangeDetectorRef } from '@angular/core';
import { NgZone } from '@angular/core';
@Component({
  selector: 'app-umberlla-quotes',
  templateUrl: './umberlla-quotes.component.html',
  imports:[NavbarComponent,NgFor,NgIf,CommonModule,RouterLink,RouterOutlet],
  styleUrls: ['./umberlla-quotes.component.css']
})
export class UmberllaQuotesComponent implements OnInit {
  
  quotes: any[] = []; 
 
  selectedQuote: any | null = null; 
  menuOpen: number | null = null;
  basePremium: number | null = null; 
  gstValue: number | null = null;
  constructor(private allquoteservice:AllClientQuotesService,private ngZone: NgZone,private cdr: ChangeDetectorRef) {}
  clientName: string = '';

  ngOnInit(): void {
    const clientDetailsRaw = localStorage.getItem('clientDetails');
    this.fetchQuotes();
    if (clientDetailsRaw) {
      const clientDetails = JSON.parse(clientDetailsRaw);
      this.clientName = clientDetails.name || 'Name not available'; 
    } else {
      this.clientName = 'Client details not found in localStorage';
    }
  }
  

  toggleMenu(id: number): void {
    
    this.menuOpen = this.menuOpen === id ? null : id;
  }
  
  fetchQuotes(): void {
    const insuredId = localStorage.getItem('insuredid');
    if (!insuredId) {
      console.error('Quote ID not found in localStorage!');
      alert('Quote ID is missing. Please check your storage.');
      return;
    }

    this.allquoteservice.getQuotes(insuredId).subscribe({
      next: (response) => {
        this.ngZone.run(() => {
          this.quotes = response;
          console.log('Fetched Quotes:', this.quotes);
        })
      },
      error: (error) => {
        console.error('Error fetching quotes:', error);
        alert('An error occurred while fetching quotes. Please try again later.');
      }
    });
  }


  hoveredQuote: number | null = null;

  softDelete(id: number) {
    console.log(`Soft deleting quote with ID: ${id}`);
    
    this.quotes = this.quotes.filter(quote => quote.id !== id);
  }
  viewQuote(quote: any): void {
    this.selectedQuote = quote; 
  
    if ( quote.umpre?.total_pernium  && !isNaN( quote.umpre?.total_pernium 
    )) {
      this.basePremium =  quote.umpre?.total_pernium     / 1.18; 
      this.gstValue =  quote.umpre?.total_pernium   - this.basePremium; 
    } else {
      console.error('Invalid totalPremium:',  quote.umpre?.total_pernium 
      );
      this.basePremium = null; 
      this.gstValue = null; 
      alert('Error: Total Premium is not a valid number!');
    }
  }
  


  closeModal(): void {
    this.selectedQuote = null; 
  }
}
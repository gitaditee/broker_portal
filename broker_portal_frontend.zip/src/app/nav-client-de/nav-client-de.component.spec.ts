import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NavClientDeComponent } from './nav-client-de.component';

describe('NavClientDeComponent', () => {
  let component: NavClientDeComponent;
  let fixture: ComponentFixture<NavClientDeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [NavClientDeComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(NavClientDeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

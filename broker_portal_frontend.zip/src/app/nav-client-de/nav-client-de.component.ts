import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-nav-client-de',
  standalone: true,
  imports:[CommonModule],
  templateUrl: './nav-client-de.component.html',
  styleUrls: ['./nav-client-de.component.css' // Corrected: 'styleUrls' instead of 'styleUrl'
  ]
})
export class NavClientDeComponent implements OnInit { // Implements OnInit
  clientDetails: any = {};
  insuredIdStr: string = 'N/A'; // Default value

  ngOnInit() {
    const storedInsuredId = localStorage.getItem("insuredid");
    if (storedInsuredId) {
      this.insuredIdStr = storedInsuredId; // Store it in the component property
    }
    console.log("Retrieved Insured ID:", this.insuredIdStr);
    
    const storedClient = localStorage.getItem("clientDetails");
    if (storedClient) {
      this.clientDetails = JSON.parse(storedClient);
      console.log("Retrieved Client Details:", this.clientDetails);
    }
  }
}
import { ComponentFixture, TestBed } from '@angular/core/testing';

import { QuoteListPageComponent } from './quote-list-page.component';

describe('QuoteListPageComponent', () => {
  let component: QuoteListPageComponent;
  let fixture: ComponentFixture<QuoteListPageComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [QuoteListPageComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(QuoteListPageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

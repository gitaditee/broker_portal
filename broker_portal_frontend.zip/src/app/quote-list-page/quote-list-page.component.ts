import { ChangeDetectorRef, Component, ViewEncapsulation } from '@angular/core';
import { RouterOutlet, RouterLink, NavigationEnd } from '@angular/router';
import { QuoteFormComponent } from '../quote-form/quote-form.component';

import { NavbarComponent } from '../navbar/navbar.component';
import { ActivatedRoute, Router } from '@angular/router';
import { NgIf } from '@angular/common';
import { ViewChild, ElementRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PopupComponent } from '../popup/popup.component';
import { jwtDecode } from "jwt-decode";
import { ClientDetailsService } from '../services/client-details.service';
import { FormsModule } from '@angular/forms';
import { AllInsuredServiceService } from '../services/all-insured-service.service';
import { AllClientQuotesService } from '../services/all-client-quotes.service';
import { MessageService } from 'primeng/api';
import { ToastModule } from 'primeng/toast';
import { CalendarModule } from 'primeng/calendar';
declare var bootstrap: any;
@Component({
  selector: 'app-quote-list-page',
  standalone: true,
  imports: [RouterOutlet,RouterLink,CommonModule,PopupComponent,CalendarModule,
    ToastModule,CommonModule,QuoteFormComponent,CommonModule,FormsModule,  NavbarComponent, NgIf],
  templateUrl: './quote-list-page.component.html',
  styleUrl: './quote-list-page.component.css'
})
export class QuoteListPageComponent {
  client = { name: '', occupation: '',startdate:new Date(),enddate:new Date() }; 

  activeStep: string = 'client-details'; 
  steps: string[] = ['client-details','all-client-details', 'assigned-details']; 
  
  constructor(   private messageService: MessageService,private cdr: ChangeDetectorRef,private clientser:ClientDetailsService,private allclientser:AllClientQuotesService, private insuredService: AllInsuredServiceService, private route: ActivatedRoute, private router: Router) {
   
    if (!this.route.snapshot.url.length) {
      this.router.navigate(['/client-details']); 
    }
    this.router.events.subscribe((event) => {
      if (event instanceof NavigationEnd) {
        const currentPath = this.route.snapshot.url[0]?.path; 
        this.activeStep = currentPath && this.steps.includes(currentPath) ? currentPath : this.steps[0];
      }
    });
   
  }
  //fn to save client details in backend using token 
 saveClient() {
    const brokerId = this.getBrokerIdFromToken();
    if (!brokerId) {
        console.error('Broker ID is missing!');
        alert('Broker ID not found. Authentication may have failed.');
        return;
    }

    try {
       
        localStorage.setItem("clientDetails", JSON.stringify(this.client));

console.log("Stored Client Details:", JSON.parse(localStorage.getItem("clientDetails") || '{}'));

        this.clientser.saveclient(
            this.client.name,
            this.client.occupation,
            this.client.startdate,
            this.client.enddate
        ).subscribe({
            next: response => {
                console.log('Client saved successfully:', response);
                this.messageService.add({
                  severity: 'info',
                  summary: 'Client saved successfully!',
                   detail: `Client saved successfully!`,
                  
                });
               
                if (response && response["insured id"]) {
                    localStorage.setItem("insuredid", response["insured id"]);
                    console.log("insured id saved", response["insured id"]);
                }
            },
            error: error => {
                console.error('Error saving client:', error);
                alert('Failed to save client. Check console for details.');
            }
        });
    } catch (error) {
        console.error('Unexpected error:', error);
        alert('An unexpected error occurred.');
    }
}

// fn to create a quote if user say they want both home & umberlla
createQuote() {
  const insuredIdStr = localStorage.getItem("insuredid");

  if (!insuredIdStr) {
      console.error('Insured ID not found in local storage');
      alert('Insured ID is missing. Please try again.');
      return;
  }

  const insuredId = Number(insuredIdStr); 
  if (isNaN(insuredId)) {
      console.error("Invalid insuredId format:", insuredIdStr);
      alert("Invalid insured ID stored. Please check your data.");
      return;
  }

  this.clientser.createQuote(insuredId).subscribe({
      next: response => {
          console.log("Quote created successfully:", response);

          if (response && response.id) {
              localStorage.setItem("quoteid", response.id.toString()); 
              console.log("Stored Quote ID:", response.id);
              
              this.messageService.add({
                severity: 'info',
                summary: 'Quote created and Quote ID saved successfully!',
                 detail: `Quote created and Quote ID saved successfully!`
               
              });
              setTimeout(() => {
                this.router.navigate(['/quote-form']);
              }, 2000);
          } else {
              console.error("Quote ID not found in response.");
              alert("Quote ID missing in response. Check console logs.");
          }

         
      },
      error: error => {
          console.error("Error creating quote:", error);
          alert("Failed to create quote. Check console for details.");
      }
  });
}
// Extract broker ID from token
private getBrokerIdFromToken(): string {
  const token = localStorage.getItem('token');

  console.log('Stored Token:', token); 

  if (!token) {
    console.error('No token found in localStorage.');
    alert('Authentication token is missing. Please log in again.');
    return ''; 
  }

  try {
    const decoded: any = jwtDecode(token);
    console.log('Decoded Token:', decoded);

    return decoded.entityId ? String(decoded.entityId) : ''; 
  } catch (error) {
    console.error('Error decoding token:', error);
    alert('Token decoding failed. Please check authentication.');
    return ''; 
  }
}

// fn to create a quote of only umberlla insurnace
createUmQuote(){
  const insuredIdStr = localStorage.getItem("insuredid");

  if (!insuredIdStr) {
      console.error('Insured ID not found in local storage');
      alert('Insured ID is missing. Please try again.');
      return;
  }

  const insuredId = Number(insuredIdStr); 
  if (isNaN(insuredId)) {
      console.error("Invalid insuredId format:", insuredIdStr);
      alert("Invalid insured ID stored. Please check your data.");
      return;
  }

  this.clientser.createQuote(insuredId).subscribe({
      next: response => {
          console.log("Quote created successfully:", response);

          if (response && response.id) {
              localStorage.setItem("quoteid", response.id.toString()); 
              console.log("Stored Quote ID:", response.id);
              this.messageService.add({
                severity: 'info',
                summary: 'Quote created saved successfully!',
                 detail: `Quote created saved successfully!`
               
              });
              setTimeout(() => {
                this.router.navigate(['/umberlla-form']);
              }, 2000);
          } else {
              console.error("Quote ID not found in response.");
              alert("Quote ID missing in response. Check console logs.");
          }

         
      },
      error: error => {
          console.error("Error creating quote:", error);
          alert("Failed to create quote. Check console for details.");
      }
  });
 
}

  navigateTo(step: string): void {
    if (this.steps.includes(step)) {
      this.router.navigate([`/${step}`]); 
    } else {
      console.error(`Invalid step: ${step}`); 
    }
  }
  @ViewChild(PopupComponent) popup!: PopupComponent;

  onYesClick(): void {
    this.popup.showPopup();
  }

  insuredList: any[] = [];
  brokerName: string = '';
  ngOnInit(): void {
    const storedBrokerName = localStorage.getItem('brokername');
    if (storedBrokerName) {
      this.brokerName = storedBrokerName;
    } else {
      this.brokerName = 'Broker name not found'; 
    }
  
    this.fetchInsuredData();
  }

  // to fetch isnured details from backend to show the list
  fetchInsuredData(): void {
    this.insuredService.getInsuredData().subscribe(
      (data) => {
        console.log('API Response:', data); 
        if (Array.isArray(data)) {
          this.insuredList = data.map(insured => ({
            ...insured,
            startdate: this.formatDate(insured.startdate),
            enddate: this.formatDate(insured.enddate)
          }));
        } else {
          console.error('Expected an array, but received:', data);
        }
      },
      (error) => {
        console.error('Error fetching insured data', error);
      }
    );
  }
  searchTerm: string = ''; // Add this property to hold the search value

  get filteredInsuredList() {
    if (!this.searchTerm) {
      return this.insuredList; // If no search term, show all
    }
    return this.insuredList.filter(insured =>
      insured.name.toLowerCase().includes(this.searchTerm.toLowerCase()) || // Search by name
      insured.id.toString().includes(this.searchTerm)                       // Search by ID
    );
  }
  formatDate(dateString: string): string {
    const date = new Date(dateString);
    return `${date.getDate()}-${date.getMonth() + 1}-${date.getFullYear()}`;
  }
  gotoquoteform(){
     this.router.navigate(['/quote-form']);
  }
 // fn to delete the isnured 
gotoDeleteClient(insuredId: number): void {
  const previousList = [...this.insuredList];
  this.insuredList = this.insuredList.filter(insured => insured.insuredId !== insuredId);
  this.allclientser.deleteCustomer(insuredId).subscribe(
    () => {
      console.log(`Customer with ID ${insuredId} deleted successfully.`);
      this.cdr.detectChanges(); 
      window.location.reload(); 
    },
    (error) => {
      console.error('Error deleting customer:', error);
      this.insuredList = previousList; 
    }
  );
}
quotes: Array<any> = [];
selectedInsuredId: number | null = null;

// fn to view the details of particular client of quote
gotoviewAllQuotes(insuredId: number): void {
  this.selectedInsuredId = insuredId; 
  console.log(`Fetching quotes for insuredId: ${insuredId}`);

  this.quotes = []; 
  const modalElement = document.getElementById('quotesModal');
  if (modalElement) {
    const modalInstance = new bootstrap.Modal(modalElement);
    modalInstance.show();
  }

  this.allclientser.getQuotesByInsuredId(insuredId).subscribe({
    next: (quotes) => {
      this.quotes = quotes;
      console.log('Quotes fetched successfully:', this.quotes);

      if (this.quotes.length === 0) {
        console.log('No quotes available for the selected insured ID.');
      }
    },
    error: (error) => {
      console.error('Error fetching quotes:', error);
      this.messageService.add({
        severity: 'error',
        summary: 'Failed to Fetch Quotes',
        detail: 'An error occurred while fetching quotes. Please try again.'
      });
    }
  });
}
// fn that automatic update the expiration date in form
updateExpirationDate(): void {
  if (this.client.startdate) {
    const inceptionDate = new Date(this.client.startdate);
    const expirationDate = new Date(inceptionDate); 
    expirationDate.setFullYear(inceptionDate.getFullYear() + 1); 
    this.client.enddate = expirationDate; 
  }
}

//pagination
currentPage: number = 1;
  itemsPerPage: number = 5; 
  totalPages: number = Math.ceil(this.insuredList.length / this.itemsPerPage);

  get paginatedList() {
    const startIndex = (this.currentPage - 1) * this.itemsPerPage;
    const endIndex = startIndex + this.itemsPerPage;
    return this.insuredList.slice(startIndex, endIndex);
  }

  get startIndex() {
    return (this.currentPage - 1) * this.itemsPerPage;
  }

  get endIndex() {
    return Math.min(this.startIndex + this.itemsPerPage, this.insuredList.length);
  }
  get pages() {
    return Array(this.totalPages)
      .fill(0)
      .map((_, i) => i + 1);
  }

  changePage(page: number): void {
    if (page >= 1 && page <= this.totalPages) {
      this.currentPage = page;
    }
  }
  // Get the broker name from localStorage


}
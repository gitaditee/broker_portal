import { Component } from '@angular/core';
import { Router, RouterLink,RouterOutlet } from '@angular/router';
import { QuoteListPageComponent } from '../quote-list-page/quote-list-page.component';
import { SignUpComponent } from '../sign-up/sign-up.component';
import { BrokerRegisterServiceService } from '../services/broker-register-service.service';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { jwtDecode } from "jwt-decode";
import { MessageService } from 'primeng/api';
import { ToastModule } from 'primeng/toast';
@Component({
  selector: 'app-sign-in',
  standalone: true,
  imports: [RouterLink,RouterOutlet,QuoteListPageComponent,ToastModule,SignUpComponent,CommonModule,FormsModule],
  providers:[MessageService],
  templateUrl: './sign-in.component.html',
  styleUrl: './sign-in.component.css'
})
export class SignInComponent {
  adminCredentials = { email: '', password: '' }; 

  constructor(private adminService: BrokerRegisterServiceService, private router: Router, private messageService: MessageService,
  ) {}
 
  loginBroker() {
    this.adminService.loginAdmin(this.adminCredentials.email, this.adminCredentials.password).subscribe({
      next: (response: any) => {
        try {
          const decodedToken: any = jwtDecode(response.token);
          
          // Storing token  in localStorage
          localStorage.setItem('token', response.token);
          console.log('Token saved:', response.token);
          
          // Extract broker ID from response 
          if (response.broker && response.broker.id ) {
            localStorage.setItem('brokerId', response.broker.id.toString());
            console.log('Broker ID saved:', response.broker.id);          
          } else {
            console.warn('Broker ID not found in response.');
          }
          if (response.broker && response.broker.name) {
            localStorage.setItem('brokername', response.broker.name);
            console.log('Broker name saved:', response.broker.name);
        } else {
            console.warn('Broker name not found in response.');
        }

          
          this.messageService.add({
            severity: 'success',
            summary: 'Login Successful',
            detail: `Broker ID: ${decodedToken.entityId}`,
            styleClass: 'custom-toast'
          });
          
          setTimeout(() => {
            this.router.navigate(['/quote-list']);
          }, 2000); 
        } catch (error) {
          console.error('Error decoding token:', error);

          this.messageService.add({
            severity: 'error',
            summary: 'Token Error',
            detail: 'Unable to decode the token.'
          });
        }
      },
      error: (err) => {
        console.error('Login failed:', err);

        
        this.messageService.add({
          severity: 'error',
          summary: 'Login Failed',
          detail: 'Please check your credentials.'
        });
      }
    });
  }

}

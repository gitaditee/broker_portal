import { Component, OnInit } from '@angular/core';
import { BrokerRegisterServiceService } from '../services/broker-register-service.service';
import { Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { MessageService } from 'primeng/api';
import { ToastModule } from 'primeng/toast';
@Component({
  selector: 'app-sign-up',
  imports: [CommonModule,FormsModule,ToastModule],
  standalone: true,
  templateUrl: './sign-up.component.html',
  styleUrl: './sign-up.component.css'
})
export class SignUpComponent implements OnInit  {
  adminData = { name: '', email: '', password: '' }; 
  constructor(private router: Router, private http:HttpClient,
    private adminService: BrokerRegisterServiceService,private messageService: MessageService ) {}
  ngOnInit(): void {}

  registerAdmin(): void {
    this.adminService.registerBroker(this.adminData).subscribe(
      (response) => {
        
        this.messageService.add({
          severity: 'success',
          summary: 'Registration Successful',
          detail: `Registration Successful, please proceed for login}`
         
        });
        // alert('Registration Successful, please proceed for login');
       // localStorage.setItem('brokerName', this.adminData.name);
        //localStorage.setItem('brokeremail',this.adminData.email);
         //this.router.navigate(['/quote-list']);
       
        this.adminData = { name: '', email: '', password: '' };
      },
      (error) => {
        console.error('Error during registration:', error);
        alert('Registration failed. Please try again.');
      }
    );
  };
  gotologinpage(){
    this.router.navigate(['/signin']); 
  }
}